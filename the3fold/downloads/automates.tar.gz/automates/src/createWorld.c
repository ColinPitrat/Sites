#include <stdio.h>
#include <stdlib.h>

#define HEIGHT 600
#define WIDTH 800

char *fileInit = "testvie.world";

int main()
{
    printf("Cr�ation du fichier %s\n",fileInit);
    FILE* F;
    if((F = fopen(fileInit,"w")) == NULL)
    {
      fprintf(stderr,"Erreur: Impossible d'ouvrir le fichier : %s\n",fileInit);
      exit(1);
    }

    unsigned int x,y;
    for(y = 0; y < HEIGHT; y++)
    {
      for(x = 0; x < WIDTH; x++)
      {
        if((x == 400) || (y == 300))
          fprintf(F,"%d ",0);
        else
          fprintf(F,"%d ",1);
      }
      fprintf(F,"\n");
    }

    fclose(F);
    exit(0);
}
