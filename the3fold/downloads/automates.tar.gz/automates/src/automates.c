#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define PROBA_MAX 10000
#define NB_MESURES_DIM 32

unsigned char Quitter                   = 0;
SDL_Surface *Screen                     = NULL;
SDL_Surface *World                      = NULL;
int selectedState                       = 0;              // Etat de cellule s�lectionn�
char *fileInit                          = NULL;
unsigned char fullscreen                = 0;
unsigned char isRunning,hideInfos;
void (*putpixel) ();
struct autom
{
	unsigned int width, height, state, voisinage;
	unsigned int *Rcouleurs, *Gcouleurs, *Bcouleurs;
	unsigned int dimension;
	Uint32 *couleurs;
	unsigned int *initProbas, *etatTr, *etatSuiv;
	unsigned int **probas;
	char **noms;
	unsigned int **monde;
} automate;

unsigned int **temp;

// Les quatres fonctions qui suivent permettent d'�crire un pixel 
// selon la profondeur de couleurs du mode utilis�
void putpixel8(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x;
	*p = pixel;
}

void putpixel16(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * 2;
	*(Uint16 *)p = pixel;
}

void putpixel24(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * 3;

	if(SDL_BYTEORDER == SDL_BIG_ENDIAN) 
	{
		p[0] = (pixel >> 16) & 0xff;
		p[1] = (pixel >> 8) & 0xff;
		p[2] = pixel & 0xff;
	} 
	else 
	{
		p[0] = pixel & 0xff;
		p[1] = (pixel >> 8) & 0xff;
		p[2] = (pixel >> 16) & 0xff;
	}
}

void putpixel32(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
	Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * 4;
	*(Uint32 *)p = pixel;
}

void drawline(SDL_Surface *surface, int xd, int yd, int xf, int yf, Uint32 color)
{
	if(xd > xf)
	{
		int temp = xd;
		xd = xf;
		xf = temp;
		temp = yd;
		yd = yf;
		yf = temp;
	}
	int dx = xf - xd;
	int dy = yf - yd;
	int y = yd;
	int eps = 0;
	int x;

	if(dy >= 0)
	{
		for(x = xd; x <= xf; x++)
		{
			if((x > 0) && (y > 0) && (x < surface->w) && (y < surface->h))
				putpixel(surface,x,y,color);
			eps += dy;
			if((eps << 1) >= dx)
			{
				y++;
				eps -= dx;
			}
		}
	}
	else
	{
		for(x = xd; x <= xf; x++)
		{
			if((x > 0) && (y > 0) && (x < surface->w) && (y < surface->h))
				putpixel(surface,x,y,color);
			eps -= dy;
			if((eps << 1) >= dx)
			{
				y--;
				eps -= dx;
			}
		}
	}
}

// Renvoi une surface contenant le texte "texte" ecrit en
// couleur "fgColor" dans la police de nom "font_face" et 
// de taille "font_size"
SDL_Surface *Texte(char *texte, char *font_face, short font_size, SDL_Color fgColor)
{
	TTF_Font *font;
	SDL_Surface *text;

	font = TTF_OpenFont(font_face, font_size); // Chargement de la police
	if (!font) 
		fprintf(stderr, "Impossible de charger la taille %dpt depuis %s: %s\n", font_size, font_face, SDL_GetError());  

	text = TTF_RenderText_Blended(font, texte, fgColor);
	if (text==NULL)
		fprintf(stderr, "Impossible de cr�er la surface contenant le texte : %s\n", SDL_GetError());

	// Fermeture de la police
	TTF_CloseFont(font); 

	return text;
}

// Initialise tout ce qu'il faut ...
void InitSDL()
{
	// Initialise la vid�o
	if(SDL_Init(SDL_INIT_VIDEO) < 0)
	{
		fprintf(stderr,"   Impossible d'initialiser la vid�o : %s.\n", SDL_GetError());
		exit(1);
	}
	atexit(SDL_Quit);

	// Choisit le mode vid�o
	if(fullscreen)
		Screen = SDL_SetVideoMode(automate.width, automate.height, 24, SDL_SWSURFACE | SDL_ANYFORMAT | SDL_FULLSCREEN);
	else
		Screen = SDL_SetVideoMode(automate.width, automate.height, 24, SDL_SWSURFACE | SDL_ANYFORMAT);


	if(Screen == NULL)
	{
		fprintf(stderr,"   Impossible de s�lectionner le mode video %dx%dx24 : %s.\n", automate.width, automate.height, SDL_GetError());
		exit(1);
	}

	// Initialise la gestion des evenements
	SDL_EnableUNICODE(1);
	SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL + 50);

	// Initialise l'affichage de texte
	if (TTF_Init() < 0) 
	{
		fprintf(stderr, "   Impossible d'initialiser SDL_TTF: %s\n",SDL_GetError());
		exit(1);
	}

	// Pointe sur les bonnes fonctions putpixel 
	unsigned char bpp = Screen->format->BytesPerPixel;
	switch(bpp)
	{
		case 1:
			putpixel = &putpixel8;
			break;
		case 2:
			putpixel = &putpixel16;
			break;
		case 3:
			putpixel = &putpixel24;
			break;
		case 4:
			putpixel = &putpixel32;
			break;
		default:
			putpixel = NULL;
			break;
	}

	// Cr�ation de la surface repr�sentant le monde
	World = SDL_CreateRGBSurface(SDL_SWSURFACE, automate.width, automate.height, Screen->format->BitsPerPixel, Screen->format->Rmask, Screen->format->Gmask, Screen->format->Bmask, Screen->format->Amask);

	// Cr�ation des couleurs des diff�rents �tats
	unsigned int i;
	for(i = 0; i < automate.state; i++)
		automate.couleurs[i] = SDL_MapRGB(World->format, automate.Rcouleurs[i], automate.Gcouleurs[i], automate.Bcouleurs[i]);
}

void CreateWorld()
{
	printf("Cr�ation du monde initial...\n");
	if(fileInit == NULL)
	{
		printf("Utilisation d'un monde al�atoire\n");
		unsigned int x,y;
		unsigned int r,i,prob;
		for(y = 0; y < automate.height; y++)
			for(x = 0; x < automate.width; x++)
			{
				r = random() % PROBA_MAX;
				prob = 0;
				for(i = 0; i < automate.state; i++)
				{
					prob += automate.initProbas[i];
					if(r < prob)
					{
						automate.monde[y][x]=i;
						temp[y][x]=i;
						break;
					}
				}
			}
	}
	else
	{
		printf("Utilisation du fichier %s\n",fileInit);
		FILE* F;
		if((F = fopen(fileInit,"r")) == NULL)
		{
			fprintf(stderr,"Erreur: Impossible d'ouvrir le fichier : %s\n",fileInit);
			exit(1);
		}

		unsigned int x,y;
		for(y = 0; y < automate.height; y++)
			for(x = 0; x < automate.width; x++)
			{
				if(fscanf(F,"%d",&(automate.monde[y][x])) < 1)
				{
					fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",fileInit);
					exit(1);
				}
				temp[y][x]=automate.monde[y][x];
			}

		fclose(F);
	}
}

void LoadWorld(char *filename)
{
	printf("Chargement de l'automate ...\n");
	FILE* F;
	if((F = fopen(filename,"r")) == NULL)
	{
		fprintf(stderr,"Erreur: Impossible d'ouvrir le fichier : %s\n",filename);
		exit(1);
	}

	if(fscanf(F,"%d",&(automate.dimension)) < 1)
	{
		fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
		exit(1);
	}
	printf(" Dimension : %d\n",(automate.dimension == 1) ? 1 : 2);

	if(fscanf(F,"%d %d",&(automate.width),&(automate.height)) < 2)
	{
		fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
		exit(1);
	}
	printf(" Largeur : %d\n Hauteur : %d\n",automate.width,automate.height);

	if(fscanf(F,"%d %d",&(automate.state),&(automate.voisinage)) < 2)
	{
		fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
		exit(1);
	}
	printf(" Nombre d'�tats : %d\n Type de voisinage : ",automate.state);
	switch(automate.voisinage)
	{
		case 1:
			printf("Von Neumann\n");
			break;
		case 2:
			printf("Moore\n");
			break;
		case 3:
			printf("Moore �tendu\n");
			break;
		default:
			printf("inconnu\n");
			fprintf(stderr,"Erreur: voisinage inconnu\n");
			exit(1);
	}

	unsigned int i=0;
	automate.noms = (char**)malloc(sizeof(char*) * automate.state);
	for(i = 0; i < automate.state; i++)
	{
		automate.noms[i] = (char*)malloc(sizeof(char) * automate.state);
	}
	automate.probas = (unsigned int**)malloc(sizeof(unsigned int*) * automate.state);
	for(i = 0; i < automate.state; i++)
	{
		automate.probas[i] = (unsigned int*)malloc(sizeof(unsigned int) * 13);
	}
	automate.Rcouleurs = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.Gcouleurs = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.Bcouleurs = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.initProbas = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.etatTr = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.etatSuiv = (unsigned int*)malloc(sizeof(unsigned int) * automate.state);
	automate.couleurs = (Uint32 *)malloc(sizeof(Uint32) * automate.state);
	automate.monde = (unsigned int**)malloc(sizeof(unsigned int*) * automate.height);
	for(i = 0; i < automate.height; i++)
	{
		automate.monde[i] = (unsigned int*)malloc(sizeof(unsigned int) * automate.width);
	}
	temp = (unsigned int**)malloc(sizeof(unsigned int*) * automate.height);
	for(i = 0; i < automate.height; i++)
	{
		temp[i] = (unsigned int*)malloc(sizeof(unsigned int) * automate.width);
	}

	for(i = 0; i < automate.state; i++)
	{
		if(fscanf(F,"%d %d %d",&(automate.Rcouleurs[i]),&(automate.Gcouleurs[i]),&(automate.Bcouleurs[i])) < 3)
		{
			fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
			exit(1);
		}
		printf(" Couleur de l'�tat %d : %d %d %d\n",i,automate.Rcouleurs[i],automate.Gcouleurs[i],automate.Bcouleurs[i]);
	}

	for(i = 0; i < automate.state; i++)
	{
		if(fscanf(F,"%s",automate.noms[i]) < 1)
		{
			fprintf(stderr,"Erreur : Impossible de lire dans le fichier : %s\n",filename);
			exit(1);
		}
		printf(" Nom de l'�tat %d : %s\n",i,automate.noms[i]);
	}

	unsigned int verif = 0;
	for(i = 0; i < automate.state; i++)
	{
		if(fscanf(F,"%d",&(automate.initProbas[i])) < 1)
		{
			fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
			exit(1);
		}
		printf(" Probabilit� initiale de l'�tat %d : %d\n",i,automate.initProbas[i]);
		verif += automate.initProbas[i];
	}
	if(verif != PROBA_MAX)
		fprintf(stderr,"Attention : La somme des probabilit�s initiales n'est pas %d mais : %d\n",PROBA_MAX,verif);

	for(i = 0; i < automate.state; i++)
	{
		if(fscanf(F,"%d %d %d %d %d %d %d %d %d %d %d %d %d %d %d",&(automate.etatTr[i]),&(automate.etatSuiv[i]),&(automate.probas[i][0]),&(automate.probas[i][1]),&(automate.probas[i][2]),&(automate.probas[i][3]),&(automate.probas[i][4]),&(automate.probas[i][5]),&(automate.probas[i][6]),&(automate.probas[i][7]),&(automate.probas[i][8]),&(automate.probas[i][9]),&(automate.probas[i][10]),&(automate.probas[i][11]),&(automate.probas[i][12])) < 13)
		{
			fprintf(stderr,"Erreur: Impossible de lire dans le fichier : %s\n",filename);
			exit(1);
		}
		printf(" Probabilit� de transition de l'�tat %d � %d selon le nombre de voisins de type %d : %d %d %d %d %d %d %d %d %d %d %d %d %d\n",i,automate.etatSuiv[i],automate.etatTr[i],automate.probas[i][0],automate.probas[i][1],automate.probas[i][2],automate.probas[i][3],automate.probas[i][4],automate.probas[i][5],automate.probas[i][6],automate.probas[i][7],automate.probas[i][8],automate.probas[i][9],automate.probas[i][10],automate.probas[i][11],automate.probas[i][12]);
		automate.etatSuiv[i]--;
	}

	fclose(F);
}

void CloseWorld()
{
	SDL_FreeSurface(World);

	free(automate.Rcouleurs);
	free(automate.Gcouleurs);
	free(automate.Bcouleurs);
	free(automate.initProbas);
	free(automate.etatTr);
	free(automate.etatSuiv);
	free(automate.couleurs);
	free(automate.noms);
	free(automate.probas);
	free(automate.monde);
	free(temp);
}

void DimCalc()
{
	// On preferera une puissance de 2 
	unsigned int cote = 1;
	// Tableau regroupant les mesures
	unsigned int resultats[NB_MESURES_DIM];
	double abs[NB_MESURES_DIM],ord[NB_MESURES_DIM];
	// Les limites de la zone �tudi�e (si on ne peut pas diviser le monde en un nombre entier de zones), et le nombre de zones sur chaque axe
	unsigned int Xmax, Ymax,nbX,nbY;
	// Nombre de zones actives, abscisse et ordonn�e de la zone courante, d�placement dans la zone pour le pixel �tudi�, compteur
	unsigned int num,x,y,dx,dy,i;
	// Si la zone courante est active
	unsigned char cover;
	i = 0;

	// Mesures n�cessaires
	while(i < NB_MESURES_DIM)
	{
		Xmax = (automate.width / cote) * cote; 
		nbX = Xmax / cote;
		Ymax = (automate.height / cote) * cote; 
		nbY = Ymax / cote;
		/*if((automate.width % cote) || (automate.height % cote))
		  {
		  printf("Attention : la longueur d'un cote %d ne divise pas la largeur %d ou la hauteur %d\n",cote,automate.width,automate.height);
		  printf("R�duit l'�tude � %d x %d\n",Xmax,Ymax);
		  }*/
		//printf("Echantillonage sur %dx%d=%d zones.\n",nbX,nbY,nbX*nbY);
		num = 0;
		for(x = 0; x < nbX; x++)
			for(y = 0; y < nbY; y++)
			{
				cover = 0;
				for(dx = 0; dx < cote; dx++)
					for(dy = 0; dy < cote; dy++)
						if(automate.monde[y*cote + dy][x*cote + dx] == (unsigned int)selectedState)
						{
							cover = 1;
						}
				if(cover)
					num++;
			}
		resultats[i] = num;
		abs[i] = log(2 * cote);
		ord[i] = log(num);
		i++;
		cote++;
	}
	// Fin des mesures

	/*printf("R�capitulatif :\n");
	  int j;
	  for(j = 0; j < NB_MESURES_DIM; j++)
	  {
	  printf("  Pour des zones de cot� %d (log (2xcot�) -> %f), on trouve %d (log(zones actives) -> %f) zones actives.\n",j,abs[j],resultats[j],ord[j]);
	  }
	  for(j = 1; j < NB_MESURES_DIM; j++)
	  {
	  printf("  Soit une pente de : %f\n",(ord[j] - ord[j-1]) / (abs[j] - abs[j-1]));
	  }
	  for(j = 0; j < NB_MESURES_DIM; j++)
	  {
	  printf("%f,%f\n",abs[j],ord[j]);
	  }*/

	unsigned char finVisu = 0;
	unsigned char showReg = 0;
	double dim;
	while(!finVisu)
	{
		// Traitement des �venements
		SDL_Event event;
		while(SDL_PollEvent(&event))
		{
			switch(event.type)
			{
				case SDL_KEYDOWN:
					switch(event.key.keysym.sym)
					{
						case SDLK_RETURN:
							printf("Affiche la regression lin�aire\n");
							showReg = 1;
							break;
						case SDLK_BACKSPACE:
							printf("Cache la regression lin�aire\n");
							showReg = 0;
							break;
						case SDLK_ESCAPE:
							finVisu = 1;
							break;
						default:
							break;
					}
					break;
				case SDL_QUIT:
					Quitter = 1;
					return;
			}
		}
		// Fin de traitement des �venements

		// Affichage du graphe
		Uint32 background = SDL_MapRGB(Screen->format, 0, 0, 0);
		Uint32 foreground = SDL_MapRGB(Screen->format, 255, 255, 255);
		Uint32 foreground2 = SDL_MapRGB(Screen->format, 255, 0, 0);
		SDL_FillRect(Screen, NULL, background);

		double maxabs = abs[0]; double minabs = abs[0]; double maxord = ord[0]; double minord = ord[0];
		double scaleVert, scaleHor;
		for(i = 0; i < NB_MESURES_DIM; i++)
		{
			if(abs[i] > maxabs)
				maxabs = abs[i];
			if(abs[i] < minabs)
				minabs = abs[i];
			if(ord[i] > maxord)
				maxord = ord[i];
			if(ord[i] < minord)
				minord = ord[i];
		}

		unsigned int marge = 10;
		scaleVert = (Screen->h - 2*marge) / (maxord - minord);
		scaleHor = (Screen->w - 2*marge) / (maxabs - minabs);

		unsigned int x,y;
		for(i = 0; i < NB_MESURES_DIM; i++)
		{
			x = scaleHor * (abs[i] - minabs) + marge;
			y = scaleVert * (ord[i] - minord) + marge;
			putpixel(Screen,x,y,foreground);
			putpixel(Screen,x,y-1,foreground);
			putpixel(Screen,x-1,y,foreground);
			putpixel(Screen,x,y+1,foreground);
			putpixel(Screen,x+1,y,foreground);
		}

		// Calcul de la droite la plus proche par regression lin�aire
		double a,b;
		{
			double t1 = 0; double t2 = 0; double t3 = 0; double t4 = 0;
			for(i = 0; i < NB_MESURES_DIM; i++)
			{
				t1 += abs[i];
				t2 += ord[i];
				t3 += abs[i] * abs[i];
				t4 += abs[i] * ord[i];
			}
			a = (NB_MESURES_DIM * t4 - t1 * t2) / (NB_MESURES_DIM * t3 - t1 * t1);
			dim = -a;
			b = (t3 * t2 - t1 * t4) / (NB_MESURES_DIM * t3 - t1 * t1);
		}

		// On l'a, maintenant on la trace
		if(showReg)
		{
			int Xdeb,Ydeb,Xfin,Yfin;
			Xdeb = marge;
			Ydeb = scaleVert * (a*minabs + b - minord) + marge;
			Xfin = Screen->w - marge;
			Yfin = scaleVert * (a*maxabs + b - minord) + marge;
			drawline(Screen,Xdeb,Ydeb,Xfin,Yfin,foreground2);
		}

		SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
		// Fin de l'affichage
	}
	// Fin de r�cup�ration du nom de fichier
	printf("Dimension calcul�e : %f\n",dim);
}

void SaveWorld()
{
	printf("Sauvegarde de l'�tat du monde ...\n");
	// R�cup�ration du nom de fichier
	char fileName[80] = "save.world";
	unsigned char length = 10;
	unsigned char nomComplet = 0;
	while(!nomComplet)
	{
		// Traitement des �venements
		SDL_Event event;
		while(SDL_PollEvent(&event))
		{
			switch(event.type)
			{
				case SDL_KEYDOWN:
					switch(event.key.keysym.sym)
					{
						case SDLK_RETURN:
							nomComplet = 1;
							break;
						case SDLK_ESCAPE:
							printf("Annulation de la sauvegarde\n");
							return;
						case SDLK_BACKSPACE:
							if(length)
							{
								length--;
								fileName[length] = 0;
							}
							break;
						case SDLK_a:
						case SDLK_b:
						case SDLK_c:
						case SDLK_d:
						case SDLK_e:
						case SDLK_f:
						case SDLK_g:
						case SDLK_h:
						case SDLK_i:
						case SDLK_j:
						case SDLK_k:
						case SDLK_l:
						case SDLK_m:
						case SDLK_n:
						case SDLK_o:
						case SDLK_p:
						case SDLK_q:
						case SDLK_r:
						case SDLK_s:
						case SDLK_t:
						case SDLK_u:
						case SDLK_v:
						case SDLK_w:
						case SDLK_x:
						case SDLK_y:
						case SDLK_z:
						case SDLK_0:
						case SDLK_1:
						case SDLK_2:
						case SDLK_3:
						case SDLK_4:
						case SDLK_5:
						case SDLK_6:
						case SDLK_7:
						case SDLK_8:
						case SDLK_9:
						case SDLK_UNDERSCORE:
						case SDLK_MINUS:
						case SDLK_PERIOD:
						case SDLK_KP_PERIOD:
						case SDLK_SPACE:
						case SDLK_SEMICOLON:
							fileName[length] = event.key.keysym.unicode;
							length++;
							fileName[length] = 0;
						default:
							break;
					}
					break;
				case SDL_QUIT:
					Quitter = 1;
					printf("Annulation de la sauvegarde\n");
					return;
			}
		}
		// Fin de traitement des �venements

		// Affichage d'une boite de message
		SDL_Surface *boite;
		boite = SDL_CreateRGBSurface(SDL_SWSURFACE, Screen->w / 2, 160, Screen->format->BitsPerPixel, Screen->format->Rmask, Screen->format->Gmask, Screen->format->Bmask, Screen->format->Amask);

		Uint32 background = SDL_MapRGB(World->format, 127, 127, 127);
		SDL_FillRect(boite, NULL, background);

		SDL_Color jaune = {255,255,0,0};

		// Cr�e le titre de la boite
		{
			SDL_Surface *titre = Texte("Nom du fichier :", "babelfish.ttf", 40, jaune);

			SDL_Rect dest; 
			dest.x = (boite->w - titre->w) / 2;
			dest.y = 15;
			dest.w = titre->w;
			dest.h = titre->h;

			SDL_BlitSurface(titre, NULL, boite, &dest);
			SDL_FreeSurface(titre);
		}

		// Cr�e la zone de texte
		{
			SDL_Surface *name = SDL_CreateRGBSurface(SDL_SWSURFACE, boite->w - 20, 60, Screen->format->BitsPerPixel, Screen->format->Rmask, Screen->format->Gmask, Screen->format->Bmask, Screen->format->Amask);

			Uint32 black = SDL_MapRGB(World->format, 0, 0, 0);
			SDL_FillRect(name, NULL, black);

			if(length)
			{
				SDL_Surface* temp = Texte(fileName,"babelfish.ttf",40, jaune);

				SDL_Rect src,dest; 
				src.x = (temp->w > name->w) ? (temp->w - name->w) : 0;
				src.y = 0;
				src.w = (temp->w > name->w) ? name->w : temp->w;
				src.h = temp->h;
				dest.x = (temp->w > name->w) ? 0 : name->w - temp->w;
				dest.y = (name->h - temp->h) / 2;
				dest.w = (temp->w > name->w) ? name->w : temp->w;
				dest.h = temp->h;

				SDL_BlitSurface(temp, &src, name, &dest);
				SDL_FreeSurface(temp);
			}

			SDL_Rect dest;
			dest.x = (boite->w - name->w) / 2;
			dest.y = 85;
			dest.w = name->w;
			dest.h = name->h;

			SDL_BlitSurface(name, NULL, boite, &dest);
			SDL_FreeSurface(name);
		}

		// On affiche le r�sultat � l'�cran
		SDL_Rect dest;
		dest.x = Screen->w / 4;
		dest.y = (Screen->h - boite->h) / 2;
		dest.w = boite->w;
		dest.h = boite->h;

		SDL_BlitSurface(boite, NULL, Screen, &dest);
		SDL_FreeSurface(boite);

		// On met � jour la zone de la boite de dialogue
		SDL_UpdateRect(Screen, dest.x, dest.y, dest.w, dest.h);
		// Fin de l'affichage
	}
	// Fin de r�cup�ration du nom de fichier

	FILE *F;
	if((F = fopen(fileName,"w")) == NULL)
	{
		fprintf(stderr,"Erreur: Impossible d'ouvrir le fichier : %s\n",fileInit);
		exit(1);
	}
	printf("  Utilisation du fichier %s\n",fileName);

	unsigned int x,y;
	for(y = 0; y < automate.height; y++)
	{
		for(x = 0; x < automate.width; x++)
		{
			fprintf(F,"%d",automate.monde[y][x]);
		}
		fprintf(F,"\n");
	}

	fclose(F);
}

void evolue()
{
	unsigned int x,y;
	unsigned int r,c,n;
	for(y = 0; y < automate.height; y++)
		for(x = 0; x < automate.width; x++)
		{
			c = automate.etatTr[automate.monde[y][x]];
			if(c == 0)
			{
				r = random() % PROBA_MAX;
				if(r < automate.probas[automate.monde[y][x]][0])
				{
					temp[y][x] = automate.etatSuiv[automate.monde[y][x]];
				}
			}
			else
			{
				c--; // Parce que dans le fichier, 0 -> pas d'�tat, mais maintenant on veut l'index de l'�tat
				n = 0;
				if(automate.dimension == 1)
				{
					if(y > 0)
					{
						switch(automate.voisinage)
						{
							case 2:
								// Voisines proches + �tat pr�c�dent correspond a 2^1 = 2
								n += (automate.monde[y - 1][x] == c) ? 1 : 0;
							case 1:
								// Voisines proches correspond a 2^0 = 1 pour gauche et 2^2 = 4 pour droite
								n += (automate.monde[y - 1][(x < 1) ? automate.width - 1 : x - 1] == c) ? 1 : 0;
								n += (automate.monde[y - 1][(x >= automate.width - 1) ? 0 : x + 1] == c) ? 1 : 0;
								break;
							default:
								break;
						}
						r = random() % PROBA_MAX;
						if(r < automate.probas[automate.monde[y][x]][n])
						{
							temp[y][x] = automate.etatSuiv[automate.monde[y][x]];
						}
					}
				}
				else
				{
					switch(automate.voisinage)
					{
						case 3:
							// Moore �tendu
							n += (automate.monde[y][(x == 0) ? automate.width - 2 : ((x == 1) ? automate.width - 1 : x - 2)] == c) ? 1 : 0;
							n += (automate.monde[y][(x == automate.width - 1) ? 1 : ((x == automate.width - 2) ? 0 : x + 2)] == c) ? 1 : 0;
							n += (automate.monde[(y == 0) ? automate.height - 2 : ((y == 1) ? automate.height - 1 : y - 2)][x] == c) ? 1 : 0;
							n += (automate.monde[(y == automate.height - 1) ? 1 : ((y == automate.height - 2) ? 0 : y + 2)][x] == c) ? 1 : 0;
						case 2:
							// Moore
							n += (automate.monde[(y < 1) ? automate.height - 1 : y - 1][(x < 1) ? automate.width - 1 : x - 1] == c) ? 1 : 0;
							n += (automate.monde[(y >= automate.height - 1) ? 0 : y + 1][(x >= automate.width - 1) ? 0 : x + 1] == c) ? 1 : 0;
							n += (automate.monde[(y < 1) ? automate.height - 1 : y - 1][(x >= automate.width - 1) ? 0 : x + 1] == c) ? 1 : 0;
							n += (automate.monde[(y >= automate.height - 1) ? 0 : y + 1][(x < 1) ? automate.width - 1 : x - 1] == c) ? 1 : 0;
						case 1:
							// Von Neumann
							n += (automate.monde[y][(x < 1) ? automate.width - 1 : x - 1] == c) ? 1 : 0;
							n += (automate.monde[y][(x >= automate.width - 1) ? 0 : x + 1] == c) ? 1 : 0;
							n += (automate.monde[(y < 1) ? automate.height - 1 : y - 1][x] == c) ? 1 : 0;
							n += (automate.monde[(y >= automate.height - 1) ? 0 : y + 1][x] == c) ? 1 : 0;
							break;
						default:
							break;
					}
					r = random() % PROBA_MAX;
					if(r < automate.probas[automate.monde[y][x]][n])
					{
						temp[y][x] = automate.etatSuiv[automate.monde[y][x]];
					}
				}
			}
		}

	for(y = 0; y < automate.height; y++)
		for(x = 0; x < automate.width; x++)
			automate.monde[y][x] = temp[y][x];
}

// Se charge de l'affichage
void affichage()
{
	Uint32 white = SDL_MapRGB(World->format, 255, 255, 255);
	Uint32 black = SDL_MapRGB(World->format, 0, 0, 0);
	SDL_FillRect(Screen, NULL, black);
	SDL_FillRect(World, NULL, white);

	// On prot�ge la surface avant d'�crire dedans
	if ( SDL_MUSTLOCK(World) ) 
	{
		if ( SDL_LockSurface(World) < 0 ) 
		{
			fprintf(stderr, "Can't lock World: %s\n", SDL_GetError());
			return;
		}
	}

	// On dessine 
	unsigned int y,x;
	for(y = 0; y < automate.height; y++)
		for(x = 0; x < automate.width; x++)
			putpixel(World, x, y, automate.couleurs[automate.monde[y][x]]);

	// On d�bloque la surface
	if ( SDL_MUSTLOCK(World) ) 
	{
		SDL_UnlockSurface(World);
	}

	// On affiche le r�sultat � l'�cran
	SDL_Rect dest; 
	dest.x = (Screen->w - World->w) / 2;
	dest.y = (Screen->h - World->h) / 2;
	dest.w = World->w;
	dest.h = World->h; 
	SDL_BlitSurface(World, NULL, Screen, &dest);

	if(!hideInfos)
	{
		SDL_Color yellow = {255,255,0,0};
		SDL_Surface* selected = Texte(automate.noms[selectedState],"babelfish.ttf",40, yellow);
		dest.x = 0;
		dest.y = 0;
		dest.w = selected->w;
		dest.h = selected->h;

		SDL_BlitSurface(selected, NULL, Screen, &dest);
		SDL_FreeSurface(selected);
	}

	// On met � jour la totalit� de l'�cran
	SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

static void process_events(void)
{
	SDL_Event event;
	int x,y;
	while(SDL_PollEvent(&event))
	{
		switch(event.type)
		{
			case SDL_KEYDOWN:
				switch(event.key.keysym.sym)
				{
					case SDLK_LEFT:
						if(--selectedState < 0)
							selectedState = 0;
						break;
					case SDLK_RIGHT:
						if(++selectedState >= (int)automate.state)
							selectedState = automate.state - 1;
						break;
					case SDLK_SPACE:
						evolue();
						break;
					case SDLK_LCTRL:
						CreateWorld();
						break;
					case SDLK_LALT:
						hideInfos = !hideInfos;
						break;
					case SDLK_RETURN:
						isRunning = 1;
						break;
					case SDLK_BACKSPACE:
						isRunning = 0;
						break;
					case SDLK_F1:
						SaveWorld();
						break;
					case SDLK_F2:
						DimCalc();
						break;
					case SDLK_ESCAPE:
						Quitter = 1;
						break;
					default:
						break;
				}
				break;
			case SDL_MOUSEBUTTONDOWN:
				SDL_GetMouseState(&x, &y);
				y -= (Screen->h - World->h) / 2;
				x -= (Screen->w - World->w) / 2;
				automate.monde[y][x] = selectedState;
				temp[y][x] = selectedState;
				break;
			case SDL_QUIT:
				Quitter = 1;
				break;
		}
	}
}

void InitApp()
{
	Quitter = 0;
	fullscreen = 0;
	selectedState = 0;
	isRunning = 0;
	hideInfos = 0;
	fileInit = NULL;

	srandom(2500);
}

void showHelp(char *progName)
{
	fprintf(stderr,"  Syntaxe : %s [options] <filename>\n\n",progName);
	fprintf(stderr,"  Options :\n -h\t Ce message d'aide\n -f\t Plein �cran\n -i\t Pr�cise un nom de fichier d'�tat initial\n\n");
	fprintf(stderr,"  Commandes : \n     * En mode simulation : \n - Return permet de lancer la simulation et Backspace de l'arr�ter.\n - Espace permet de faire �voluer pas � pas.\n - Control (droit) permet de r�initialiser le monde.\n - Echap permet de quitter\n - F1 permet de sauvegarder l'�tat de l'automate\n - F2 permet d'effectuer un calcul de la dimension par la m�thode des boites.\n - Droite et Gauche permettent de modifier l'�tat s�lectionn�.\n - Un clic de souris permet de placer la cellule cliqu�e dans l'�tat s�lectionn�\n");
	fprintf(stderr,"     * En mode calcul de dimension : \n - Return permet de calculer et d'afficher la r�gression lin�aire\n - Backspace permet de masquer la r�gression lin�aire\n - Echap permet de retourner au mode simulation\n");
	exit(0);
}

int main(int argc, char* argv[])
{
	InitApp();

	char c;

	// h : help
	// f : fullscreen
	// i : fichier d'�tat initial (� pr�ciser)
	while ((c = getopt(argc, argv, "hfi:")) != -1)
		switch (c) 
		{
			case 'f':
				fullscreen = 1;
				break;
			case 'i':
				fileInit = optarg;
				break;
			case 'v':
				break;
			case '?':
				fprintf(stderr, "Erreur : Option inconnue `-%c'.\n", optopt);
			case 'h':
			default:
				showHelp(argv[0]);
				break;
		};

	if(argc - optind == 1)
	{
		LoadWorld(argv[optind]);
		InitSDL();
		CreateWorld();

		while(!Quitter)
		{
			if(isRunning)
				evolue();
			affichage();
			process_events();
		}

		CloseWorld();
		exit(0);
	}
	else
		showHelp(argv[0]);
	exit(0);
}
