#!/usr/bin/perl -w

use strict;
use MIME::Base64;
use config;
require 'functions.pm';

############
# Configuration from config.pm
############
my $gnatsdir = $config::gnats_dir;
my $project_num = $config::first_project; 
my $user_num = $config::first_user;
my $bug_num = $config::first_bug;
my $bug_text_num = $config::first_bug_text;
my $bug_file_num = $config::first_bug_file;
my $project_view_state = $config::project_default_view_status;
my $project_description = $config::project_default_description;
open(SQL, ">".$config::sql_output);

# List all the projects
opendir(DIR, $gnatsdir) || die "Error : Can't opendir $gnatsdir : $!\n";
my @projects = grep { /^[^\.]/ && -d "$gnatsdir/$_" } readdir(DIR);
closedir DIR;

my $project;
my @users_list;

############
# Exporting project by project
############
foreach $project (@projects)
{
        print "Exporting ".$project."\n";
        ############
        # Exporting the project infos
        ############
        print SQL "INSERT INTO mantis_project_table (id, name, view_state, description) VALUES ($project_num, \"$project\", $project_view_state, ".SqlEncode($project_description).");\n";

        ############
        # Exporting categories
        ############
        {
                my $cat_file = $gnatsdir."/".$project."/gnats-adm/categories";
                (-f $cat_file) || die "Error : $cat_file not found\n";
                open(CATEGORIES, $cat_file) || die "Error : Can't open $cat_file : $!\n";
                my $line;
                while ($line = <CATEGORIES>)
                {
                        unless($line =~ /^#/)
                        {
                                my @categorie = [split(/:/, $line)];
                                print SQL "INSERT INTO mantis_project_category_table (project_id, category) VALUES ($project_num, \"$categorie[0][0]\");\n";
                        }
                }
                close(CATEGORIES);
        }

        ############
        # Exporting users
        ############
        {
                my $users_file = $gnatsdir."/".$project."/gnats-adm/gnatsd.access";
                (-f $users_file) || die "Error : $users_file not found\n";
                open(USERS, $users_file) || die "Error : Can't open $users_file : $!\n";
                my $line;
                while ($line = <USERS>) 
                {
                        unless($line =~ /^#/ || $line !~ /[^:]*:[^:]*:[^:]*:/)
                        {
                                my @user = [split(/:/, $line)];
                                if($user[0][0] ne "*" && $user[0][0] ne "" && !is_in($user[0][0], @users_list))
                                {
                                        push(@users_list, $user[0][0]);
                                        # We need something for the cookie string, because it's a unique key.
                                        # This must not be something that can't be guess by a hacker as it is 
                                        # used to keep user authenticated.
                                        # I use the md5 of (time + random) as in Mantis
                                        my $cookie_seed = time + rand(100000);
                                        print SQL "INSERT INTO mantis_user_table (id, username, password, cookie_string) VALUES ($user_num, \"";
                                        print SQL $user[0][0]."\", MD5(\"";
                                        print SQL $user[0][1]."\"), MD5(\"";
                                        print SQL $cookie_seed."\"));\n";
                                        print SQL "INSERT INTO mantis_project_user_list_table (project_id, user_id, access_level) VALUES ($project_num, $user_num, ".config::get_access_level($user[0][2]).");\n";
                                        $user_num = $user_num + 1;
                                }
                        }
                }
        }

        ############
        # Exporting bugs
        ############
        {
                my $index_file = $gnatsdir."/".$project."/gnats-adm/index";
                (-f $index_file) || die "Error : $index_file not found\n";
                open(INDEX, $index_file) || die "Error : Can't open $index_file : $!\n";
                my $line;
                while ($line = <INDEX>) 
                {
                        my %data;
                        $data{arrival} = "";
                        $data{modified} = "";
                        $data{description} = "";
                        $data{reproduce} = "";
                        $data{fix} = "";
                        $data{note} = "";
                        $data{audit} = "";
                        $data{unformatted} = "";
                        my @fields = split(/\|/, $line);
                        my $bug_file = $gnatsdir."/".$project."/".$fields[0];
                        open(BUG, $bug_file) || die "Error : Can't open $bug_file : $!\n";
                        while ($line = <BUG>)
                        {
                                if($line =~ /^>Arrival-Date: *(.*)$/)
                                {
                                        $data{arrival} = $1;
                                }
                                if($line =~ /^>Last-Modified: *(.*)$/)
                                {
                                        $data{modified} = $1;
                                }
                                if($line =~ /^>Description:$/) 
                                {
                                        $data{description} = getMultiLineField(\*BUG);
                                }
                                if($line =~ /^>How-To-Repeat:$/) 
                                {
                                        $data{reproduce} = getMultiLineField(\*BUG);
                                }
                                if($line =~ /^>Fix:$/) 
                                {
                                        $data{fix} = getMultiLineField(\*BUG);
                                }
                                if($line =~ /^>Release-Note:$/) 
                                {
                                        $data{note} = getMultiLineField(\*BUG);
                                }
                                if($line =~ /^>Audit-Trail:$/) 
                                {
                                        $data{audit} = getMultiLineField(\*BUG);
                                }
                                if($line =~ /^>Unformatted:$/)
                                {
                                        my $end;
                                        do
                                        {
                                                $end = 1;
                                                my $filename = "";
                                                my $filetype = "";

                                                # Jump the header
                                                while($line = <BUG>) 
                                                {
                                                        $end = 0;
                                                        #if(undef($line)) { $end = 1; goto fin_corps; }
                                                        if($line !~ /-/) { last; } 
                                                        if($line =~ /filename=\"([^\"]*)\"/)
                                                        {
                                                                $filename = $1;
                                                        }
                                                        if($line =~ /Content-Type: ([^;]*);/)
                                                        {
                                                                $filetype = $1;
                                                        }
                                                        $data{unformatted} = ""; 
                                                }

                                                # Copy the content
                                                while($line = <BUG>) 
                                                {
                                                        if($line =~ /-/) { last; }
                                                        $data{unformatted} .= $line;
                                                }

                                                if($filename ne "")
                                                {
                                                        my $content = SqlEncode(decode_base64($data{unformatted}));
                                                        my $filesize = length($content);
                                                        print SQL "INSERT INTO mantis_bug_file_table (id, bug_id, diskfile, filename, filesize, file_type, content) VALUES ($bug_file_num, $bug_num, MD5($content), ".SqlEncode($filename).", $filesize, ".SqlEncode($filetype).", $content);\n";
                                                        $bug_file_num = $bug_file_num + 1;
                                                }
                                        }until($end);
                                }
                        }
                        my @cat = split(/\//, $fields[0]);
                        close(BUG);

                        # Build query to insert bug
                        my $begin_query = "INSERT INTO mantis_bug_table (id, bug_text_id, project_id, priority, severity, status, category, summary, version, ";
                        my $end_query = " VALUES ($bug_num, $bug_text_num, $project_num, ".config::get_priority($fields[6]).", ".config::get_severity($fields[5]).", ".config::get_status($fields[3]).", \"$cat[0]\", ".SqlEncode($fields[13]).", ".SqlEncode($fields[12]).", ";
                        if($data{arrival})
                        {
                                $begin_query .= "date_submitted, ";
                                $end_query .= "\"".gnatsdate2mantisdate($data{arrival})."\", ";
                        }
                        if($data{modified})
                        {
                                $begin_query .= "last_updated, ";
                                $end_query .= "\"".gnatsdate2mantisdate($data{modified})."\", ";
                        }
                        $begin_query .= "view_state) ";
                        $end_query .= config::get_view_status($fields[4]).");\n"; 

                        print SQL $begin_query.$end_query;

                        # GNATS has some fields that are not in standards Mantis fields. We could put it in custom fields that we should define and add in every imported project, but I choose to put it all together in the Additional Information
                        my $additional = "";
                        if($data{audit})
                        {
                                $additional .= $data{audit}; 
                        }
                        if($data{fix})
                        {
                                $additional .= $data{fix}; 
                        }
                        if($data{note})
                        {
                                $additional .= $data{note};
                        }
                        print SQL "INSERT INTO mantis_bug_text_table (id, description, steps_to_reproduce, additional_information) VALUES ($bug_text_num, ".SqlEncode($data{description}).", ".SqlEncode($data{reproduce}).", ".SqlEncode($additional).");\n";
                        $bug_num = $bug_num + 1;
                        $bug_text_num = $bug_text_num + 1;
                }
        }
        close(INDEX);

        # XXX liste etats
        $project_num = $project_num + 1;
}
