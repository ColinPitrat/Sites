#!/usr/bin/perl -w

use strict;
use MIME::Base64;
use config;
require 'functions.pm';

############
# Configuration from config.pm
############
my $gnatsdir = $config::gnats_dir;
my $project_num = $config::first_project; 
my $user_num = $config::first_user;
my $bug_num = $config::first_bug;
my $bug_text_num = $config::first_bug_text;
my $bug_file_num = $config::first_bug_file;
my $project_view_state = $config::project_default_view_status;
my $project_description = $config::project_default_description;
open(SQL, ">".$config::sql_output);

# List all the projects
opendir(DIR, $gnatsdir) || die "Error : Can't opendir $gnatsdir : $!\n";
my @projects = grep { /^[^\.]/ && -d "$gnatsdir/$_" } readdir(DIR);
closedir DIR;

my $project;
my @users_list;
my @projects_users_couples;
my %mails;
my %names;
my %projects_nums;
my %users_nums;

############
# Exporting project by project
############
foreach $project (@projects)
{
        print "Exporting ".$project."\n";
        ############
        # Exporting the project infos
        ############
	$projects_nums{$project} = $project_num;
        print SQL "INSERT INTO mantis_project_table (id, name, view_state, description) VALUES ($project_num, \"$project\", $project_view_state, ".SqlEncode($project_description).");\n";

        ############
        # Exporting categories
        ############
        {
                my $cat_file = $gnatsdir."/".$project."/gnats-adm/categories";
                (-f $cat_file) || die "Error : $cat_file not found\n";
                open(CATEGORIES, $cat_file) || die "Error : Can't open $cat_file : $!\n";
                my $line;
                while ($line = <CATEGORIES>)
                {
                        unless($line =~ /^#/)
                        {
                                my @categorie = [split(/:/, $line)];
                                print SQL "INSERT INTO mantis_project_category_table (project_id, category) VALUES ($project_num, \"$categorie[0][0]\");\n";
                        }
                }
                close(CATEGORIES);
        }

        ############
        # Exporting users
        ############
        {
                # Import mails
                my $mails_file = $gnatsdir."/".$project."/gnats-adm/addresses";
                (-f $mails_file) || die "Error : $mails_file not found\n";
                open(MAILS, $mails_file) || die "Error : Can't open $mails_file : $!\n";
                my $line;
                while ($line = <MAILS>)
                {
                        unless($line =~ /^#/ || $line !~ /[^:]*:/)
                        {
                                my @mail = [split(/:/, $line)];
                                unless($mails{$mail[0][0]})
                                {
                                        $mails{$mail[0][0]} = $mail[0][1];
                                }
                        }
                }
		close(MAILS);

                # Import names
                my $names_file = $gnatsdir."/".$project."/gnats-adm/responsible";
                (-f $names_file) || die "Error : $names_file not found\n";
                open(NAMES, $names_file) || die "Error : Can't open $names_file : $!\n";
                while ($line = <NAMES>)
                {
                        unless($line =~ /^#/ || $line !~ /[^:]*:[^:]*:/)
                        {
                                my @name = [split(/:/, $line)];
                                unless($names{$name[0][0]})
                                {
                                        $names{$name[0][0]} = $name[0][1];
                                }
                        }
                }
		close(NAMES);

		# Import users for each project
                my $users_file = $gnatsdir."/".$project."/gnats-adm/gnatsd.access";
                (-f $users_file) || die "Error : $users_file not found\n";
                open(USERS, $users_file) || die "Error : Can't open $users_file : $!\n";
                while ($line = <USERS>) 
                {
                        unless($line =~ /^#/ || $line !~ /[^:]*:[^:]*:[^:]*:/)
                        {
                                my @user = [split(/:/, $line)];
                                if($user[0][0] ne "*" && $user[0][0] ne "")
                                {
					if(!is_in($user[0][0], @users_list))
					{
						push(@users_list, $user[0][0]);
						$users_nums{$user[0][0]} = $user_num;
						unless($names{$user[0][0]})
						{
							$names{$user[0][0]} = $config::default_realname;
						}
						unless($mails{$user[0][0]})
						{
							$mails{$user[0][0]} = $config::default_mail;
						}
						# We need something for the cookie string, because it's a unique key.
						# This must not be something that can't be guess by a hacker as it is 
						# used to keep user authenticated.
						# I use the md5 of (time + random) as in Mantis
						my $cookie_seed = time + rand(4000000000);
						print SQL "INSERT INTO mantis_user_table (id, username, password, cookie_string, realname, email) VALUES ($user_num, \"";
						print SQL $user[0][0]."\", MD5(\"";
						print SQL $user[0][1]."\"), MD5(\"";
						print SQL $cookie_seed."\"), ";
						print SQL SqlEncode($names{$user[0][0]}).", ";
						print SQL SqlEncode($mails{$user[0][0]}).");\n";
						$user_num = $user_num + 1;
					}
					insert_user_in_project($users_nums{$user[0][0]}, $project_num, $user[0][2]);
                                }
                        }
                }
		close(USERS);
        }

        ############
        # Exporting bugs
        ############
        {
                my $index_file = $gnatsdir."/".$project."/gnats-adm/index";
                (-f $index_file) || die "Error : $index_file not found\n";
                open(INDEX, $index_file) || die "Error : Can't open $index_file : $!\n";
                my $line;
                while ($line = <INDEX>) 
                {
                        my %data;
                        $data{arrival} = "";
                        $data{modified} = "";
                        $data{description} = "";
                        $data{reproduce} = "";
                        $data{fix} = "";
                        $data{note} = "";
                        $data{audit} = "";
                        $data{unformatted} = "";
                        my @fields = split(/\|/, $line);
                        my $bug_file = $gnatsdir."/".$project."/".$fields[0];
                        open(BUG, $bug_file) || die "Error : Can't open $bug_file : $!\n";
                        while ($line = <BUG>)
                        {
                                if($line =~ /^>Arrival-Date: *(.*)$/)
                                {
                                        $data{arrival} = $1;
                                }
                                if($line =~ /^>Last-Modified: *(.*)$/)
                                {
                                        $data{modified} = $1;
                                }
                                if($line =~ /^>Description:$/) 
                                {
                                        $data{description} = getMultiLineField(\*BUG, \$line);
                                        redo;
                                }
                                if($line =~ /^>How-To-Repeat:$/) 
                                {
                                        $data{reproduce} = getMultiLineField(\*BUG, \$line);
                                        redo;
                                }
                                if($line =~ /^>Fix:$/) 
                                {
                                        $data{fix} = getMultiLineField(\*BUG, \$line);
                                        redo;
                                }
                                if($line =~ /^>Release-Note:$/) 
                                {
                                        $data{note} = getMultiLineField(\*BUG, \$line);
                                        redo;
                                }
                                if($line =~ /^>Audit-Trail:$/) 
                                {
                                        $data{audit} = getMultiLineField(\*BUG, \$line);
                                        redo;
                                }
                                if($line =~ /^>Unformatted:$/)
                                {
                                        my $end;
                                        do
                                        {
                                                $end = 1;
                                                my $filename = "";
                                                my $filetype = "";
                                                my $base64 = 0;

                                                # Jump the header
                                                while($line = <BUG>) 
                                                {
                                                        $end = 0;
                                                        #if(undef($line)) { $end = 1; goto fin_corps; }
                                                        if($line !~ /-/) { last; } 
                                                        if($line =~ /filename=\"([^\"]*)\"/)
                                                        {
                                                                $filename = $1;
                                                        }
                                                        if($line =~ /Encoding: base64/)
                                                        {
                                                                $base64 = 1;
                                                        }
                                                        if($line =~ /Content-Type: ([^;]*);/)
                                                        {
                                                                $filetype = $1;
                                                        }
                                                        $data{unformatted} = ""; 
                                                }

                                                # Copy the content
                                                while($line = <BUG>) 
                                                {
                                                        if($line =~ /----gnatsweb-attachment----/) { last; }
                                                        $data{unformatted} .= $line;
                                                }

                                                if($filename ne "")
                                                {
                                                        my $content = $data{unformatted};
                                                        if($base64)
                                                        {
                                                                $content = decode_base64($content); 
                                                        }
                                                        $content = SqlEncode($content);
                                                        my $filesize = length($content);
                                                        my $query = "INSERT INTO mantis_bug_file_table (id, bug_id, diskfile, filename, filesize, file_type, content) VALUES ($bug_file_num, $bug_num, MD5($content), ".SqlEncode($filename).", $filesize, ".SqlEncode($filetype).", $content);\n";
                                                        my $querysize = length($query);

                                                        if($querysize < $config::sql_max_allowed_packet)
                                                        {
                                                                print SQL $query
                                                        }
                                                        else
                                                        {
                                                                print "Warning : $filename not imported in bug $bug_num because its size ($filesize) makes query size ($querysize) exceeds sql_max_allowed_packet : $config::sql_max_allowed_packet\n";
                                                        }
                                                        $bug_file_num = $bug_file_num + 1;
                                                }
                                        }until($end);
                                }
                        }
                        my @cat = split(/\//, $fields[0]);
                        close(BUG);

                        # Build query to insert bug
                        my $begin_query = "INSERT INTO mantis_bug_table (id, bug_text_id, project_id, priority, severity, status, category, summary, version, ";
                        my $end_query = " VALUES ($bug_num, $bug_text_num, $project_num, ".config::get_priority($fields[6]).", ".config::get_severity($fields[5]).", ".config::get_status($fields[3]).", \"$cat[0]\", ".SqlEncode($fields[13]).", ".SqlEncode($fields[12]).", ";
                        if($data{arrival})
                        {
                                $begin_query .= "date_submitted, ";
                                $end_query .= "\"".gnatsdate2mantisdate($data{arrival})."\", ";
                        }
                        if($data{modified})
                        {
                                $begin_query .= "last_updated, ";
                                $end_query .= "\"".gnatsdate2mantisdate($data{modified})."\", ";
                        }
                        else
                        {
                                # If no modification date is given but an arrival date is,
                                # use arrival as last modification as in Mantis
                                if($data{arrival})
                                {
                                        $begin_query .= "last_updated, ";
                                        $end_query .= "\"".gnatsdate2mantisdate($data{arrival})."\", ";
                                }
                        }
                        $begin_query .= "view_state) ";
                        $end_query .= config::get_view_status($fields[4]).");\n"; 

                        print SQL $begin_query.$end_query;

                        # GNATS has some fields that are not in standards Mantis fields. We could put it in custom fields that we should define and add in every imported project, but I choose to put it all together in the Additional Information
                        my $additional = "";
                        if($data{audit})
                        {
                                $additional .= $data{audit}; 
                        }
                        if($data{fix})
                        {
                                $additional .= $data{fix}; 
                        }
                        if($data{note})
                        {
                                $additional .= $data{note};
                        }
                        print SQL "INSERT INTO mantis_bug_text_table (id, description, steps_to_reproduce, additional_information) VALUES ($bug_text_num, ".SqlEncode($data{description}).", ".SqlEncode($data{reproduce}).", ".SqlEncode($additional).");\n";
                        $bug_num = $bug_num + 1;
                        $bug_text_num = $bug_text_num + 1;
                }
		close(INDEX);
        }

        # XXX liste etats
        $project_num = $project_num + 1;
}

############
# Exporting global users 
############
(-f $config::global_users_file) || die "Error : $config::global_users_file not found\n";
open(USERS, $config::global_users_file) || die "Error : Can't open $config::global_users_file : $!\n";
my $line;
while ($line = <USERS>)
{
	unless($line =~ /^#/ || $line !~ /[^:]*:[^:]*:[^:]*:/)
	{
		my @user = [split(/:/, $line)];
		# Should never happen in the global gnatsd.access
		if($user[0][0] ne "*" && $user[0][0] ne "")
		{
			if(!is_in($user[0][0], @users_list))
			{
				push(@users_list, $user[0][0]);
				$users_nums{$user[0][0]} = $user_num;

				unless($names{$user[0][0]})
				{
					$names{$user[0][0]} = $config::default_realname;
				}
				unless($mails{$user[0][0]})
				{
					$mails{$user[0][0]} = $config::default_mail;
				}

				# We need something for the cookie string, because it's a unique key.
				# This must not be something that can't be guess by a hacker as it is 
				# used to keep user authenticated.
				# I use the md5 of (time + random) as in Mantis
				my $cookie_seed = time + rand(4000000000);
				print SQL "INSERT INTO mantis_user_table (id, username, password, cookie_string, realname, email) VALUES ($user_num, \"";
				print SQL $user[0][0]."\", MD5(\"";
				print SQL $user[0][1]."\"), MD5(\"";
				print SQL $cookie_seed."\"), ";
				print SQL SqlEncode($names{$user[0][0]}).", ";
				print SQL SqlEncode($mails{$user[0][0]}).");\n";
				$user[0][3] =~ m/^(.*)$/;
				$user[0][3] = $1;
				if($user[0][3] eq "*")
				{
					my $proj;
					foreach $proj (@projects)
					{
						insert_user_in_project($user_num, $projects_nums{$proj}, $user[0][2]);
					}
				}
				else
				{
					my $proj;
					my @projs = split(/,/, $user[0][3]);
					foreach $proj (@projs)
					{
						if(is_in($proj, @projects))
						{
							insert_user_in_project($user_num, $projects_nums{$proj}, $user[0][2]);
						}
						else
						{
							print "Warning : unknown project $proj in rights definition for user $user_num in global conf\n";
						}
					}
				}
				$user_num = $user_num + 1;
			}
		}
		else
		{
			print "Warning : Can't understand the following line in $config::global_users_file (line $.): \n\t$line\n"
		}
	}
}
close(USERS);

# Insert a couple user project
sub insert_user_in_project
{
	my($user_num, $project_num, $access_level) = @_;

	if(!is_in($project_num."-".$user_num, @projects_users_couples))
	{
		print SQL "INSERT INTO mantis_project_user_list_table (project_id, user_id, access_level) VALUES ($project_num, $user_num, ".config::get_access_level($access_level).");\n";
		push(@projects_users_couples, $project_num."-".$user_num);
	}
	else
	{
		print "Warning : User $user_num (".get_key_of($user_num, %users_nums).") already defined in this project ($project_num : ".get_key_of($project_num, %projects_nums)."), not re-imported.\n";
	}
}

