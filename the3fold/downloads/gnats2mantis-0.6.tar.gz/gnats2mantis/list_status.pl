#!/usr/bin/perl -w

use strict;
use config;
require 'functions.pm';

# List all the projects
opendir(DIR, $config::gnats_dir) || die "can't opendir $config::gnats_dir : $!";
my @projects = grep { /^[^\.]/ && -d "$config::gnats_dir/$_" } readdir(DIR);
closedir DIR;

my @status;

my $project;
############
# Search status in all projects
############
if(defined($ARGV[0]) && $ARGV[0] eq "all")
{
	foreach $project (@projects)
	{
		my $states_file = $config::gnats_dir."/".$project."/gnats-adm/states";
		(-f $states_file) || die "$states_file not found\n";
		open(STATES, $states_file);
		my $line;
		while ($line = <STATES>) 
		{
			if($line !~ /^#/ && $line =~ /:.*:/)
			{
				my @fields = split(/:/, $line);
				if(!is_in($fields[0],@status))
				{
					push(@status, $fields[0]);
				}
			}
		}
	}
}
elsif(!defined($ARGV[0]) || $ARGV[0] eq "used")
{
	foreach $project (@projects)
	{
		my $index_file = $config::gnats_dir."/".$project."/gnats-adm/index";
		(-f $index_file) || die "$index_file not found\n";
		open(INDEX, $index_file);
		my $line;
		while ($line = <INDEX>) 
		{
			my @fields = split(/\|/, $line);
			if(!is_in($fields[3],@status))
			{
				push(@status, $fields[3]);
			}
		}
	}
}
else
{
	print "Error : Unknown argument $ARGV[0]\n";
}

############
# Print all the status
############
my $stat;
foreach $stat (@status)
{
        print "$stat\n";
}
