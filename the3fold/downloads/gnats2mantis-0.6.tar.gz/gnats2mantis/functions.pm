#!/usr/bin/perl -w

use strict;

# Find the key associated to a value in a hash map (assumes it's unique)
# (Just for occasional use, or making a reverse table would be more efficient)
sub get_key_of
{
	my($value, %hash) = @_;
	my($key,$val);
	while (($key, $val) = each %hash) 
	{
		if($val == $value)
		{
			return $key;
		}
	}
	return "_not found_";
}

# Read a multiline field from a bug file
sub getMultiLineField
{
        my($file, $line) = @_;
        my $data = "";
        $$line = <$file>;
        while($$line !~ /^>/)
        {
                $data .= $$line;
                $$line = <$file>;
        }
        return $data;
}

# Encode a string to include in a SQL query
sub SqlEncode
{
        my($text) = @_;
        if($text)
        {
                $text =~ s/([\"\'\\])/\\$1/g;

                $text =~ s/\0/\\0/g;
                $text =~ s/\n/\\n/g;
                $text =~ s/\r/\\r/g;
                $text =~ s/\t/\\t/g;

                $text =~ /^(.*)$/s;
                $text = "'$1'";
        }
        else
        {
                $text = "''";
        }
        return $text;
}

# Convert gnats date to mantis date :
# "ddd mmm DD hh:mm:ss **** YYYY" => "YYYY-MM-DD hh:mm:ss"
sub gnatsdate2mantisdate
{
        my($gdate) = @_;
	$gdate =~ s/  (\d) / 0$1 /g;
        my @parts = split(/[ :]/, $gdate);

        $parts[1] = month2number($parts[1]);

        return $parts[7]."-".$parts[1]."-".$parts[2]." ".$parts[3].":".$parts[4].":".$parts[5];
}

# Convert a three letters month code in two digits month number
sub month2number 
{
    my($month) = @_;

    if ($month =~ /jan/i) {
        return "01";
    } elsif ($month =~ /feb/i) {
        return "02";
    } elsif ($month =~ /mar/i) {
        return "03";
    } elsif ($month =~ /apr/i) {
        return "04";
    } elsif ($month =~ /may/i) {
        return "05";
    } elsif ($month =~ /jun/i) {
        return "06";
    } elsif ($month =~ /jul/i) {
        return "07";
    } elsif ($month =~ /aug/i) {
        return "08";
    } elsif ($month =~ /sep/i) {
        return "09";
    } elsif ($month =~ /oct/i) {
        return "10";
    } elsif ($month =~ /nov/i) {
        return "11";
    } elsif ($month =~ /dec/i) {
        return "12";
    } else {
        return 0;
    }
}

# Check if an element is in an array
sub is_in
{
        my($elem,@array) = @_;
        my $val;
        foreach $val (@array)
        {
                if($elem eq $val)
                {
                        return 1;
                }
        }
        return 0;
}

1;
