#!/usr/bin/perl -w

############
# Configuration for GNATS to Mantis export
# Edit it to fit your needs 
############

package config;
use strict;

# Directory where the gnats database can be found
# This directory should contain one directory per project
# Each project directory should contain one directory per
# category and a gnats-adm directory for the conf.
our $gnats_dir = "gnats";

# Address of global users file
our $global_users_file = "gnats/users";

# Id of the first imported project (1 if you have no project in Mantis)
our $first_project = 1;

# Id of the first imported user (2 if you have no other user in Mantis than the original administrator)
our $first_user = 2;

# Id of the first imported bug (1 if you have no bug in Mantis)
our $first_bug = 1;

# Id of the first imported bug file (1 if you have no bug file in Mantis)
our $first_bug_file = 1;

# Id of the first imported bug text. 
# Generally the same as $first_bug, but not necessarly.
our $first_bug_text = $first_bug;

# Default view status for the projects
# 10 for public and 50 for private in Mantis default configuration.
our $project_default_view_status = 50;

# Default description for the projects
our $project_default_description = "Imported from GNATS";

# Default mail for users
our $default_mail = '';

# Default real name for users
our $default_realname = '';

# File to execute in order to import data in Mantis
our $sql_output = "mantis.sql";

# Max file size in MySQL (if we try to insert a file that is too big, import could fail)
# You can still have an error like that
# ERROR 1153 (08S01) at line XXXX: Got a packet bigger than 'max_allowed_packet' bytes
our $sql_max_allowed_packet = 32 * 1024 * 1024;

# Method used by Mantis to upload files :
# 1 - FTP 
# 2 - DISK
# 3 - DATABASE (default)
# XXX : 1 and 2 are not implemented yet
our $file_upload_method = 3;

# Mapping of GNATS access_level to Mantis access_levels
# XXX : These settings may be not very good
my %access_level = (
        'deny'      => 0,
        'none'      => 10,
        'view'      => 25,
        'viewconf'  => 25,
        'edit'      => 25,
        'admin'     => 50,
);

# Default access_level (when not found in %access_level)
my $default_access_level = 10;

# Mapping of GNATS severity to Mantis severity level
# It seems that severity is hardcoded in GNATS
my %severity = (
        'critical' => 60,
        'serious' => 50,
        'non-critical' => 40,

        'genante' => 40,
        'grave' => 50,
        'bloquante' => 60,
        'non-genante' => 30,
);

# Default severity (when not found in %severity)
my $default_severity = 40;

# Mapping of GNATS severity to Mantis severity level
# It seems that severity is hardcoded in GNATS
my %priority = (
        'high' => 40,
        'medium' => 30,
        'low' => 20,
);

# Default priority (when not found in %priority)
my $default_priority = 30;

# Mapping of GNATS confidentiality to Mantis view_status for bugs
# Should not be changed unless you add bug/bugnotes view_status to your Mantis configuration
my %view_status = (
        'no'        => 10,
        'yes'       => 50,
);

# Default view status (when not found in %view_status)
my $default_view_status = 10;

# Mapping of GNATS status to Mantis status
# The status should be created per project to fit GNATS workflow
# And the mapping should then be generated automatically per project
# But per project status is buggy for now in Mantis.
# TODO : This will be easy to update when it will work
my %status = (
        'open' => 10,
        'suspended' => 20,
        'accepted' => 30,
        'analysing' => 30,
        'analysed' => 40,
        'analysee_a_corriger' => 40,
        'analyzed' => 40,
        'fix_scheduled' => 40,
        'feedback' => 50,
        'corrected' => 50,
        'delivered' => 70,
	'instruite_annulee' => 80,
        'rejected' => 80,
        'closed' => 90,
);

# Default bug status (when not found in %status)
my $default_status = 10;

############
# Methods to easily access to the configuration
#  !!! Do not edit !!!
############

sub get_access_level
{
        my ($lev) = @_;
        if($access_level{$lev})
        {
                return $access_level{$lev};
        }
        print "Warning : Unknown key in access_level hash map : $lev\n";
        return $default_access_level;
}

sub get_severity
{
        my ($lev) = @_;
        if($severity{$lev})
        {
                return $severity{$lev};
        }
        print "Warning : Unknown key in severity hash map : $lev\n";
        return $default_severity;
}

sub get_priority
{
        my ($lev) = @_;
        if($priority{$lev})
        {
                return $priority{$lev};
        }
        print "Warning : Unknown key in priority hash map : $lev\n";
        return $default_priority;
}

sub get_view_status
{
        my ($lev) = @_;
        if($view_status{$lev})
        {
                return $view_status{$lev};
        }
        print "Warning : Unknown key in view_status hash map : $lev\n";
        return $default_view_status;
}

sub get_status
{
        my ($lev) = @_;
        if($status{$lev})
        {
                return $status{$lev};
        }
        print "Warning : Unknown key in status hash map : $lev\n";
        return $default_status;
}

1;
