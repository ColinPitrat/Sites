#include "Game.h"

Game::Game()
{
  Configuration *configuration = Configuration::getConfiguration();
  if(configuration->debug())
    std::cerr << "Construction : game" << std::endl;
  level = NULL;
  vaisseau = new Vaisseau();
  vies = NB_VIES;
  numLevel = 0;
  score = 0;
}

Game::~Game()
{
  Configuration *configuration = Configuration::getConfiguration();
  if(configuration->debug())
    std::cerr << "Destruction : game" << std::endl;
  if(vaisseau)
    delete vaisseau;
  if(level)
    delete level;
}

bool Game::nextLevel(std::string filename)
{
  Configuration *configuration = Configuration::getConfiguration();
  numLevel++;
  if(!configuration->nosound())
    level->stopMusic();
  if(level)
    delete level;
  level = NULL;
  
  std::ifstream levelsList;
  std::string levelName;
  unsigned int nbLevels;

  // Recherche le fichier correspondant au prochain level dans la liste des levels
  {
    levelsList.open(filename.c_str(),std::ios::in);
    if(!levelsList)
      std::cerr << "Impossible d'ouvrir le fichier " << filename << std::endl;

    levelsList >> nbLevels;

    if(levelsList.fail())
      std::cerr << "Erreur lors de la lecture du fichier " << filename << std::endl;

    if(numLevel > nbLevels)
      return false;

    for(unsigned int i = 0; i < numLevel; i++)
      levelsList >> levelName;

    if(levelsList.fail())
      std::cerr << "Erreur lors de la lecture du fichier " << filename << std::endl;

    levelsList.close();
  }
  level = new Level(levelName);
  if(!configuration->nosound())
    level->playMusic();

  return true;
}

void Game::afficher()
{
  level->afficher();
  vaisseau->afficher();

  // Affiche les stats
  SDL_Surface *Screen = SDL_GetVideoSurface();
  std::string infos;
  std::ostringstream oss (std::ostringstream::out);

  oss << "Level : " << this->numLevel << "   Score : " << this->score << "   Vies : " << this->vies << "   Energie : ";
  infos = oss.str();

  SDL_Color color;
  color.r = 255; color.g = 255; color.b = 0;
  SDL_Surface *Infos = Texte(infos.c_str(), "fonts/babelfish.ttf", 40, color);
  SDL_BlitSurface(Infos, NULL, Screen, NULL);

  SDL_Rect ligne;
  ligne.x = Infos->w;
  ligne.y = 5;
  ligne.w = 101;
  ligne.h = 1;
  SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
  ligne.y = 25;
  SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
  ligne.y = 5;
  ligne.w = 1;
  ligne.h = 21;
  SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
  ligne.x = Infos->w + 101;
  SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
  ligne.x = Infos->w + 1;
  ligne.y = 6;
  ligne.w = (100 * vaisseau->getEnergie()) / vaisseau->getEnergieMax();
  ligne.h = 19;
  SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 0, 0, 255));

  SDL_FreeSurface(Infos);
}

void Game::animer(double delay)
{
  level->animer(delay);
  vaisseau->animer(delay);
}

void Game::collisions()
{
  std::list<Ennemi*>* ennemis = level->getEnnemList();
  std::list<Projectile*>* projectiles = level->getProjList();
  std::list<Bonus*>* bonus = level->getBonusList();

  // G�re les collisions bonus / vaisseau
  {
    std::list<Bonus*>::iterator it = bonus->begin();
    while((it != bonus->end()) && ((*it)->getPos() < level->getPos()))
    {
      Sprite *bonus = (*it)->getSkin();
      Sprite *vaiss = vaisseau->getSprite();
      if(vaiss->collision(bonus))
      {
        // TODO : G�rer l'action du bonus
        // Note : on peut modifier n'importe quel objet : Game, Level, Vaisseau, Ennemis, Bonus, Projectiles ...
        // Il faut d�velopper un "langage" de script permettant de sp�cifier :
        //  - un objet ou une classe d'objets (le vaisseau, le jeu, le level, tous les ennemis ...)
        //  - une propri�t� � affecter
        //  - une action sur cette propri�t�
        //  - des param�tres
        //
        // Exemples : 
        //  - game score incr�menter "nombre de points"
        //  - vaisseau vie positionner maximum
        //  - "ennemis visibles" energie positionner 0
        //
        // Il faut aussi pouvoir pr�ciser plusieurs r�gles pour pouvoir cr�er des bonus ayant plusieurs actions.
        //
        executeAction((*it)->getType()->getActions(), (*it)->getType()->getNbActions());
        (*it)->detruire();
      }
      it++;
    }
  }

  // G�re les collisions ennemis / vaisseau
  {
    std::list<Ennemi*>::iterator it = ennemis->begin();
    while((it != ennemis->end()) && ((*it)->getPos() < level->getPos()))
    {
      if((*it)->getEnergie())
      {
        Sprite *ennemi = (*it)->getSkin();
        Sprite *vaiss = vaisseau->getSprite();
        if(vaiss->collision(ennemi))
        {
          vaisseau->endommager((*it)->getDegats());
          (*it)->detruire();
        }
      }
      it++;
    }
  }

  // G�re les collisions projectiles / ennemis
  {
    std::list<Ennemi*>::iterator enneIt = ennemis->begin();
    while(enneIt != ennemis->end() && (*enneIt)->getPos() < level->getPos())
    {
      if((*enneIt)->getEnergie())
      {
        Sprite *ennemi = (*enneIt)->getSkin();
        std::list<Projectile*>::iterator projIt = projectiles->begin();
        while(projIt != projectiles->end())
        {
          if(!(*projIt)->getExplose())
          {
            Sprite *proj = (*projIt)->getSkin();
            if(ennemi->collision(proj))
            {
              (*projIt)->detruire();
              score += (*enneIt)->endommager((*projIt)->getDegats());
            }
          }
          projIt++;
        }
      }
      enneIt++;
    }
  }
}

// Ce qui est impl�ment� pour l'instant :
//  - score : add, sub
//  - lives : add, sub
//  - energy : add, sub, set
void Game::executeAction(BonusAction *actions, int nbActions)
{
  for(int i=0; i < nbActions; i++)
  {
    // On compare l'objet � tous les objets connus, puis la fonction � appliquer � toutes les fonctions connues.
    // Il faudrait trouver un moyen de n'avoir � impl�menter qu'une fois chaque m�thode, et non pour chaque cible
    // en en faisant abstraction.
    if(actions[i].objet == "score")
    {
      if(actions[i].action == "add")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int bonus;
          iss >> bonus;
          score += bonus;
        }
      }
      if(actions[i].action == "sub")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int malus;
          iss >> malus;
          if(malus >= score)
            score = 0;
          else
            score -= malus;
        }
      }
    }
    if(actions[i].objet == "lives")
    {
      if(actions[i].action == "add")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int bonus;
          iss >> bonus;
          vies += bonus;
        }
      }
      if(actions[i].action == "sub")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int malus;
          iss >> malus;
          if(malus >= vies)
            vies = 0;
          else
            vies -= malus;
        }
      }
    }
    if(actions[i].objet == "energy")
    {
      if(actions[i].action == "add")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int bonus;
          iss >> bonus;
          vaisseau->reparer(bonus);
        }
      }
      if(actions[i].action == "sub")
      {
        if(actions[i].nbParams > 0)
        {
          std::istringstream iss (actions[i].parametres[0]);
          unsigned int malus;
          iss >> malus;
          vaisseau->endommager(malus);
        }
      }
      if(actions[i].action == "set")
      {
        if(actions[i].nbParams > 0)
        {
          if(actions[i].parametres[0] == "max")
          {
            vaisseau->setEnergie(vaisseau->getEnergieMax());
          }
          else
          {
            std::istringstream iss (actions[i].parametres[0]);
            unsigned int bonus;
            iss >> bonus;
            std::cout << "Essaie de mettre l'energie � : " << bonus << std::endl << "A comparer � energieMax : " << vaisseau->getEnergieMax() << std::endl;
            vaisseau->setEnergie(bonus);
            std::cout << "Du coup, l'energie se retrouve � : " << vaisseau-> getEnergie() << std::endl;
          }
        }
      }
    }
  }
}
