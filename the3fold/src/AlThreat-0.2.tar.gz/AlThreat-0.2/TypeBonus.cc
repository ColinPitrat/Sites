#include "TypeBonus.h"

TypeBonus::TypeBonus(std::string filename)
{
  Configuration *configuration = Configuration::getConfiguration();
  if(configuration->debug())
    std::cerr << "Construction : type bonus" << std::endl;
  std::ifstream fichier;
  fichier.open(filename.c_str(), std::ios::in);
  if(!fichier)
    std::cerr << "Impossible d'ouvrir le fichier " << filename << std::endl;

  std::string sonName;
  std::string skinName;

  fichier >> skinName >> sonName >> nbActions;
  actions = new BonusAction[nbActions];
  for(int i=0; i < nbActions; i++)
  {
    fichier >> actions[i].objet >> actions[i].action >> actions[i].nbParams;
    actions[i].parametres = new std::string[actions[i].nbParams];
    for(int j=0; j < actions[i].nbParams; j++)
      fichier >> actions[i].parametres[j];
  }

  if(fichier.fail())
    std::cerr << "Erreur lors de la lecture du fichier " << filename << std::endl;

  skin = new SpriteData(skinName);

  son = Mix_LoadWAV(sonName.c_str());

  fichier.close();
}

TypeBonus::~TypeBonus()
{
  Configuration *configuration = Configuration::getConfiguration();
  if(configuration->debug())
    std::cerr << "Destruction : type bonus" << std::endl;
  delete skin;
  Mix_FreeChunk(son);
}
