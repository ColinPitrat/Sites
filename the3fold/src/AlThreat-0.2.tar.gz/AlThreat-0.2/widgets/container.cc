#include "container.h"

Container::Container()
{
}

Container::~Container()
{
  // Il y a un choix � faire : la destruction du container engendre la destruction de son contenu ou non
  // Pour l'instant, on choisit de ne pas d�truire le contenu. Pour une bonne utilisation, il faut faire appel
  // � clear ou a deleteAll avant de d�truire le conteneur.
  liste.clear();
}

int Container::filtre(const SDL_Event *event)
{
  typeliste::iterator i = liste.begin();
  while(i != liste.end())
  {
    if(!((*i)->filtre(event)))
      return 0;
    ++i;
  }
  return 1;
}

void Container::afficher(SDL_Surface *Screen)
{
  typeliste::iterator i = liste.begin();
  while(i != liste.end())
  {
    (*i)->afficher(Screen);
    ++i;
  }
}

void Container::deleteAll()
{
  typeliste::iterator i = liste.begin();
  while(i != liste.end())
  {
    delete *i;
    i = liste.erase(i);
  }
}

void Container::onFocus(bool foc)
{
  focused = foc;
}
