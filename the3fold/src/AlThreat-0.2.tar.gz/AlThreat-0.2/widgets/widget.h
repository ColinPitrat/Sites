#ifndef _T3F_SDL_WIDGET
#define _T3F_SDL_WIDGET

#include "SDL/SDL.h"

// On a besoin de savoir que la classe FocusContainer existe pour r�soudre les d�pendances
class FocusContainer;

class Widget
{
public:
  Widget() { focused = false; container = NULL; };
  virtual ~Widget() {};

  virtual void afficher(SDL_Surface *Screen) = 0;
  virtual int filtre(const SDL_Event *event) = 0;

  void setFocus(bool foc);
  void setContainer(FocusContainer *c) { container = c; };

  // Place le flag focused. Ne doit pas �tre appel�e directement
  virtual void onFocus(bool foc) = 0;

protected:
  FocusContainer *container;
  bool focused;
};

#endif
