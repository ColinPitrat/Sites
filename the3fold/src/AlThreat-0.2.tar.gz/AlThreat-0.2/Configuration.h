#ifndef _ALTHREAT_CONF
#define _ALTHREAT_CONF

#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>
#include <iostream>

class Configuration
{
  public:
    static Configuration *getConfiguration() { return configuration ? configuration : new Configuration(); };
    ~Configuration();

    bool nosound() { return _nosound; };
    bool fullscreen() { return _fullscreen; };
    bool verbose() { return _verbose; };
    bool debug() { return _debug; };
    int musicvol() { return _musicvol; };
    int soundFXvol() { return _soundFXvol; };

    bool toggleFullscreen() { _fullscreen = !_fullscreen; SDL_WM_ToggleFullScreen(SDL_GetVideoSurface()); return _fullscreen; };
    //bool toggleNosound();
    void setMusicVol(unsigned int vol) { _musicvol = vol; if(!_nosound) Mix_VolumeMusic(vol); };
    void setSoundFXVol(unsigned int vol) { _soundFXvol = vol; if(!_nosound) Mix_Volume(-1, vol); };
    void setNoSound(bool opt) { _nosound = opt; };
    void setFullscreen(bool opt) { _fullscreen = opt; };
    void setVerbose(bool opt) { _verbose = opt; };
    void setDebug(bool opt) { _debug = opt; };
    //bool save(std::string filename);
  private:
    Configuration();

    static Configuration *configuration;
    int _musicvol;
    int _soundFXvol;
    bool _nosound;
    bool _fullscreen;
    bool _verbose;
    bool _debug;
};

#endif
