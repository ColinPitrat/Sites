#include <iostream>
#include <string>
#include <unistd.h>
#include "Game.h"
#include "Menu.h"
#include "Level.h"
#include "Vaisseau.h"
#include "Configuration.h"

#define MAX(x,y) (((x) > (y)) ? (x) : (y))
#define MIN(x,y) (((x) < (y)) ? (x) : (y))

Game *jeu;
unsigned int level = 0;

// G�re les �venements durant le jeu
static void jeu_events(unsigned int &dir, unsigned char &shoot, unsigned char &FinJeu)
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            FinJeu = 1;
            break;
          case SDLK_UP:
            dir |= Haut;
            break;
          case SDLK_DOWN:
            dir |= Bas;
            break;
          case SDLK_RIGHT:
            dir |= Droite;
            break;
          case SDLK_LEFT:
            dir |= Gauche;
            break;
          case SDLK_SPACE:
            shoot = 1;
            break;
          default:
            break;
        }
        break;
      case SDL_KEYUP:
        switch(event.key.keysym.sym)
        {
          case SDLK_UP:
            dir -= Haut;
            break;
          case SDLK_DOWN:
            dir -= Bas;
            break;
          case SDLK_RIGHT:
            dir -= Droite;
            break;
          case SDLK_LEFT:
            dir -= Gauche;
            break;
          case SDLK_SPACE:
            shoot = 0;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        FinJeu = 1;
        break;
      default:
        break;
    }
  }
}

// Affiche l'aide sur la ligne de commande
void info(std::string appname)
{
  std::cout << "Usage : " << appname << " <options>\n";
  std::cout << "  Options :\n\t-h : Affiche ce message d'aide (help)\n\t-f : Plein �cran (fullscreen)\n\t-m : Pas de son (mute)\n\t-v : Informations d�taill�es (verbose)\n\t-d : Informations de d�bogage (debug)\n";
}

void Jeu()
{
  unsigned char FinJeu = 0;
  unsigned int dir = Arret;
  SDL_Surface *Screen = SDL_GetVideoSurface();
  std::string levelsListName("levels/levels.lst");
  SDL_ShowCursor(SDL_DISABLE);
  Configuration *configuration = Configuration::getConfiguration();

  Uint32 beginning = SDL_GetTicks();
  Uint32 frames = 0;
  while(!FinJeu && !jeu->getVaisseau()->isDead())
  {
    FinJeu = !jeu->nextLevel(levelsListName);
    level++;
    unsigned char shoot = 0;
    Uint32 debut = SDL_GetTicks();

    while((!FinJeu) && (jeu->getLevel()->getPos() < jeu->getLevel()->getEnd()) && !jeu->getVaisseau()->isDead())
    {
      jeu->animer(((double)SDL_GetTicks() - debut) / 10);
      debut = SDL_GetTicks();
      jeu->collisions();

      jeu_events(dir, shoot, FinJeu);
      jeu->getVaisseau()->setDirection(dir);

      if(shoot)
        jeu->tirer();

      SDL_FillRect(Screen, NULL, 0);  

      jeu->afficher();                    
      SDL_Flip(Screen);                  
      frames++;                           
    }
    Uint32 end = SDL_GetTicks();
    if(configuration->verbose())
      std::cout << frames << " images en " << ((double)end - beginning) / 1000 << " secondes -> " << (double)frames * 1000 / ((double)end - beginning) << "FPS\n";
  }

  delete jeu;
  jeu = NULL;
}

int main(int argc, char *argv[])
{
  Configuration *configuration = Configuration::getConfiguration();

  // Traitement des options
  // -m : pas de son
  // -h : affiche l'aide
  // -f : plein ecran
  // -w : fenetr�
  // -v : mode verbeux
  {
    char c;
    while ((c = getopt(argc, argv, "mhfwvd")) != -1)
    {
      switch(c)
      {
        case 'm':
          configuration->setNoSound(true);
          break;
        case 'f':
          configuration->setFullscreen(true);
          break;
        case 'w':
          configuration->setFullscreen(false);
          break;
        case 'v':
          configuration->setVerbose(true);
          break;
        case 'd':
          configuration->setDebug(true);
          break;
        case '?':
          std::cerr << "Erreur : Option inconnue `-" << optopt << "'.\n";
          exit(-1);
        case 'h':
        default:
          info(argv[0]);
          exit(0);
      }
    }
  }

  InitSDL();

  unsigned char Quitter = 0;
  Menu *menu = Menu::getMenu();

  bool reinit = true;
  while(!Quitter)
  {
    if(reinit)
    {
      menu->init();
    }
    switch(menu->show(jeu))
    {
      case 0:
        Jeu();
        reinit = true;
        break;
      case 1:
        reinit = true;
        break;
      /*case 2:
        reinit = false;
        break;
      case 3:
        reinit = false;
        break;*/
      case 4:
        // Ne devrait pas �tre necessaire, mais ne fait pas de mal
        if(!configuration->nosound()) Mix_HaltMusic();
        Quitter = 1;
        break;
      default:
        std::cerr << "Erreur : choix de menu inconnu.\n";
        reinit = false;
        break;
    }
  }
  delete menu;

  if(!configuration->nosound()) Mix_CloseAudio();
  SDL_Quit();
  delete configuration;
  return 0;
}
