#include "Menu.h"

Menu *Menu::menu = NULL;

Menu::Menu()
{
  musique = NULL;
  menuLayer = NULL;
  optionsLayer = NULL;
  creditsLayer = NULL;
  texte = NULL;
  fond = NULL;

  SDL_Surface *Screen = SDL_GetVideoSurface();
  configuration = Configuration::getConfiguration();
  if(!configuration->nosound())
  {
    musique = Mix_LoadMUS("sons/Menusong.ogg");
    if(!musique)
      std::cerr << "Erreur lors du chargement de la musique du menu : " << Mix_GetError() << std::endl;

  }
  fond = loadImage("images/Menu.png");
  Selected = 0;

  nbChoix = 5;
  texte = new char*[nbChoix];
  texte[0] = "Aventure";
  texte[1] = "Entrainement";
  texte[2] = "Options";
  texte[3] = "Credits";
  texte[4] = "Quitter";

  SDL_Rect dest[nbChoix];
  MenuButton *choixBoutons[nbChoix];
  menuLayer = new FocusContainer();
  for(int i = 0; i < nbChoix; i++)
  {
    dest[i].w = 180; 
    dest[i].h = 40;
    dest[i].x = (Screen->w - dest[i].w) / 2;
    dest[i].y = (Screen->h - nbChoix * dest[i].h - (nbChoix - 1) * dest[i].h / 2) / 2 + i * dest[i].h + (i - 1) * dest[i].h;
    choixBoutons[i] = new MenuButton(dest[i], texte[i], i, &Selected, &choisi);
    choixBoutons[i]->setFont("fonts/babelfish.ttf", 30);
    menuLayer->addWidget(choixBoutons[i]);
  }
  menuLayer->focus(choixBoutons[0]);
}

Menu::~Menu()
{
  if(musique)
  {
    Mix_HaltMusic();
    Mix_FreeMusic(musique);
  }
  if(fond)
  {
    SDL_FreeSurface(fond);
  }
  if(texte)
  {
    delete[] texte;
  }
  if(menuLayer)
  {
    // TODO : Il serait plus logique que la destruction du conteneur d�truise le contenu
    // Si on veut pr�server le contenu, on fait un clear
    menuLayer->deleteAll();
    delete menuLayer;
  }
  if(optionsLayer)
  {
    optionsLayer->deleteAll();
    delete optionsLayer;
  }
  if(creditsLayer)
  {
    creditsLayer->deleteAll();
    delete creditsLayer;
  }
}

void Menu::init()
{
  SDL_ShowCursor(SDL_ENABLE);

  if(musique && (Mix_FadeInMusic(musique, -1, 1000) == -1))
  {
    std::cerr << "Erreur : Impossible de jouer la musique du menu : " << Mix_GetError() << std::endl;
  }
}

void Menu::show_options()
{
  // TODO : Volume musique / Volume effets sonores
  // TODO : Qualit� (r�duire la qualit� des sons, des textes  ...)
  Configuration *conf = Configuration::getConfiguration();
  SDL_Surface *Screen = SDL_GetVideoSurface();
  View *view = View::getView();
  okOptions = false;
  cancelOptions = false;
  bool fs_var = conf->fullscreen();
  int mus_vol = conf->musicvol();
  int fx_vol = conf->soundFXvol();

  if(!optionsLayer)
  {
    // TODO : Cr�er les widgets pour le Layer
    optionsLayer = new FocusContainer();

    SDL_Rect fs_pos;
    fs_pos.x = 70; fs_pos.y = 150; fs_pos.w = 300; fs_pos.h = 25;
    std::string textefs = "Plein ecran";
    Checkbox *fs_box = new Checkbox(fs_pos, textefs, &fs_var);
    fs_box->setImages("images/on.png", "images/off.png");
    fs_box->setFont("fonts/vera.ttf", 20);
    fs_box->setBorderSize(0);

    SDL_Rect mus_label_pos;
    mus_label_pos.x = 70; mus_label_pos.y = 200; mus_label_pos.w = 250; mus_label_pos.h = 25;
    Label *mus_label = new Label(mus_label_pos, "Volume musique :", T3F_LEFT);
    mus_label->setFont("fonts/vera.ttf", 20);
    mus_label->setBorderSize(0);

    SDL_Rect mus_pos;
    mus_pos.x = 330; mus_pos.y = 200; mus_pos.w = 300; mus_pos.h = 25;
    Jauge *mus_jauge = new Jauge(mus_pos, 0, MIX_MAX_VOLUME, &mus_vol, T3F_HOR);

    SDL_Rect fx_label_pos;
    fx_label_pos.x = 70; fx_label_pos.y = 235; fx_label_pos.w = 250; fx_label_pos.h = 25;
    Label *fx_label = new Label(fx_label_pos, "Volume effets sonores :", T3F_LEFT);
    fx_label->setFont("fonts/vera.ttf", 20);
    fx_label->setBorderSize(0);

    SDL_Rect fx_pos;
    fx_pos.x = 330; fx_pos.y = 235; fx_pos.w = 300; fx_pos.h = 25;
    Jauge *fx_jauge = new Jauge(fx_pos, 0, MIX_MAX_VOLUME, &fx_vol, T3F_HOR);

    SDL_Rect ok_pos;
    ok_pos.x = 100; ok_pos.y = 500; ok_pos.w = 80; ok_pos.h = 25;
    Switch *ok_bouton = new Switch(ok_pos, "OK", &okOptions);
    ok_bouton->setFont("fonts/vera.ttf", 20);

    SDL_Rect cancel_pos;
    cancel_pos.x = 250; cancel_pos.y = 500; cancel_pos.w = 80; cancel_pos.h = 25;
    Switch *cancel_bouton = new Switch(cancel_pos, "Cancel", &cancelOptions);
    cancel_bouton->setFont("fonts/vera.ttf", 20);

    if(conf->nosound())
    {
      mus_label->setActive(false);
      mus_jauge->setActive(false);
      fx_label->setActive(false);
      fx_jauge->setActive(false);
    }

    optionsLayer->addWidget(fs_box);
    optionsLayer->addWidget(mus_label);
    optionsLayer->addWidget(mus_jauge);
    optionsLayer->addWidget(fx_label);
    optionsLayer->addWidget(fx_jauge);
    optionsLayer->addWidget(ok_bouton);
    optionsLayer->addWidget(cancel_bouton);
    optionsLayer->focus(ok_bouton);
  }
  view->clear();
  view->addWidget(optionsLayer);

  while(!(okOptions || cancelOptions))
  {
    SDL_BlitSurface(fond, NULL, Screen, NULL);
    view->afficher(Screen);
    SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
    options_events();
  }
  if(okOptions)
  {
    if(conf->fullscreen() != fs_var)
      conf->toggleFullscreen();
    if(mus_vol != conf->musicvol() && !conf->nosound())
    {
      conf->setMusicVol(mus_vol);
      Mix_HaltMusic();
      if(!musique || (Mix_FadeInMusic(musique, -1, 1000) == -1))
      {
        std::cerr << "Erreur : Impossible de jouer la musique du menu : " << Mix_GetError() << std::endl;
      }
    }
    if(fx_vol != conf->soundFXvol() && !conf->nosound())
    {
      conf->setSoundFXVol(fx_vol);
    }
  }
}

void Menu::options_events()
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_RETURN:
            okOptions = true;
          case SDLK_ESCAPE:
            cancelOptions = true;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        cancelOptions = true;
        break;
      default:
        break;
    }
  }
}

void Menu::show_credits()
{
  SDL_Surface *Screen = SDL_GetVideoSurface();
  FinCredits = false;

  if(!creditsLayer)
  {
    creditsLayer = new FocusContainer();

    SDL_Rect ok_pos;
    ok_pos.x = 360; ok_pos.y = 525; ok_pos.w = 80; ok_pos.h = 25;
    Switch *ok_bouton = new Switch(ok_pos, "OK", &FinCredits);
    ok_bouton->setFont("fonts/vera.ttf", 20);

    creditsLayer->addWidget(ok_bouton);
    creditsLayer->focus(ok_bouton);
  }

  View *view;
  view = View::getView();
  view->clear();

  view->addWidget(creditsLayer);
  while(!FinCredits)
  {
    affichage_credits();
    view->afficher(Screen);
    SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
    credits_events();
  }
}

void Menu::affichage_credits()
{
  SDL_Surface *Screen = SDL_GetVideoSurface();

  SDL_Color blue = { 0, 255, 255, 0};
  SDL_Color yellow = { 255, 255, 0, 0 };
  SDL_Color red = { 255, 0, 0, 0 };

  SDL_Surface *text1 = Texte("Programmation : Skippy", "fonts/babelfish.ttf", 40, blue);
  SDL_Surface *text2 = Texte("Graphismes : Raz & Skippy", "fonts/babelfish.ttf", 40, blue);
  SDL_Surface *text3 = Texte("Musique : Raz & Vavrek", "fonts/babelfish.ttf", 40, blue);
  SDL_Surface *text4 = Texte("-=( the3fold )=-", "fonts/babelfish.ttf", 40, yellow);
  SDL_Surface *text5 = Texte("http://www.vavrek.com", "fonts/vera.ttf", 20, red);
  SDL_Surface *text6 = Texte("http://the3fold.free.fr", "fonts/vera.ttf", 20, red);

  SDL_Rect rect1 = { 70, 200, text1->w, text1->h };
  SDL_Rect rect2, rect3, rect4;
  SDL_Rect rect5 = { 90, 420, text5->w, text5->h };
  SDL_Rect rect6 = { 90, 470, text6->w, text6->h };
  //rect1.x = 70; rect1.y = 200; rect1.w = text1->w; rect1.h = text1->h;
  rect2.x = 70; rect2.y = 250; rect2.w = text2->w; rect2.h = text2->h;
  rect3.x = 70; rect3.y = 300; rect3.w = text3->w; rect3.h = text3->h;
  rect4.x = 500; rect4.y = 450; rect4.w = text4->w; rect4.h = text4->h;

  SDL_BlitSurface(fond, NULL, Screen, NULL);
  SDL_BlitSurface(text1, NULL, Screen, &rect1);
  SDL_BlitSurface(text2, NULL, Screen, &rect2);
  SDL_BlitSurface(text3, NULL, Screen, &rect3);
  SDL_BlitSurface(text4, NULL, Screen, &rect4);
  SDL_BlitSurface(text5, NULL, Screen, &rect5);
  SDL_BlitSurface(text6, NULL, Screen, &rect6);
}

void Menu::credits_events()
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
          case SDLK_RETURN:
            FinCredits = true;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        FinCredits = true;
        break;
      default:
        break;
    }
  }
}

void Menu::affichage_menu()
{
  SDL_Surface *Screen = SDL_GetVideoSurface();
  SDL_BlitSurface(fond, NULL, Screen, NULL);

  SDL_Color color;
  color.r = 255; color.g = 255; color.b = 0;

  SDL_Surface *options[nbChoix];
  for(int i=0; i<nbChoix; i++)
  {
    if(Selected == i)
      color.r = 0;
    else
      color.r = 255;
    options[i] = Texte(texte[i], "fonts/babelfish.ttf", 50, color);
  }

  SDL_Rect dest[nbChoix];
  for(int i = 0; i < nbChoix; i++)
  {
    dest[i].x = (Screen->w - options[i]->w) / 2;
    dest[i].y = (Screen->h - nbChoix * options[i]->h - (nbChoix - 1) * options[i]->h / 2) / 2 + i * options[i]->h + (i - 1) * options[i]->h;
    dest[i].w = options[i]->w; 
    dest[i].h = options[i]->h;
  }

  for(int i=0; i<nbChoix; i++)
  {
    SDL_BlitSurface(options[i], NULL, Screen, &dest[i]);
  }

  SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

void Menu::menu_events()
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            // Quitter doit �tre le dernier choix
            Selected = nbChoix - 1;
            choisi = true;
            break;
          case SDLK_UP:
            if(--Selected < 0)
              Selected += nbChoix;
            menuLayer->focusPrev();
            break;
          case SDLK_DOWN:
            if(++Selected >= nbChoix)
              Selected -= nbChoix;
            menuLayer->focusNext();
            break;
          case SDLK_RETURN:
            choisi = true;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        Selected = nbChoix - 1;
        choisi = true;
        break;
      default:
        break;
    }
  }
}

unsigned char Menu::show(Game *&jeu)
{
  choisi = false;

  View *view = View::getView();

  while(!choisi)
  {
    SDL_Surface *Screen = SDL_GetVideoSurface();
    view->clear();
    view->addWidget(menuLayer);

    while(!choisi)
    {
      SDL_BlitSurface(fond, NULL, Screen, NULL);
      view->afficher(Screen);
      SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);

      menu_events();
    }

    view->clear();

    switch(Selected)
    {
      case 0:
        jeu = new Game();
        break;
      case 1:
        break;
      case 2:
        show_options();
        choisi = false;
        break;
      case 3:
        show_credits();
        choisi = false;
        break;
      case 4:
      default:
        break;
    }
  }

  return Selected;
}
