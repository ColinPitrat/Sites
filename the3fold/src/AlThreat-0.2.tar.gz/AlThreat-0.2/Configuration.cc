#include "Configuration.h"

Configuration *Configuration::configuration = NULL;

Configuration::Configuration()
{
  _nosound = false;
  _fullscreen = false;
  _verbose = false;
  _debug = false;
  _musicvol = MIX_MAX_VOLUME;
  _soundFXvol = MIX_MAX_VOLUME;
  configuration = this;
}

Configuration::~Configuration()
{
}

/*bool Configuration::toggleNosound()
{
  if(nosound())
  {
    if(SDL_InitSubSystem(SDL_INIT_AUDIO) < 0)
    {
      std::cerr << "Impossible d'initialiser SDL : " << SDL_GetError() << std::endl;
      return true;
    }
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1)
    {
      std::cerr << "Impossible d'ouvrir le canal audio : " << Mix_GetError() << std::endl;
      return true;
    }
    Mix_Volume(-1, _soundFXvol);
    Mix_VolumeMusic(_musicvol);
    _nosound = false;
    return false;
  }
  else
  {
    SDL_QuitSubSystem(SDL_INIT_AUDIO);
    Mix_CloseAudio();
    _nosound = true;
    return true;
  }
}*/

/*bool Configuration::save(std::string filename)
{
  // Sauvegarder la configuration
  return true;
}*/
