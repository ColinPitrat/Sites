#ifndef _ALTHREAT_GAME
#define _ALTHREAT_GAME

#include <sstream>
#include "Level.h"
#include "Vaisseau.h"
#include "graphics.h"
#include "Configuration.h"

#define NB_VIES 2

class Game
{
public:
  // Constructeur/Destructeur
  Game();
  ~Game();

  // Accesseurs
  bool nextLevel(std::string);
  Level *getLevel() { return level; };
  Vaisseau *getVaisseau() { return vaisseau; };
  void afficher();
  void animer(double delay);
  void tirer() { vaisseau->tirer(level->getProjList()); };
  void collisions();
  void executeAction(BonusAction *actions, int nbActions);

  // Methodes
  //void addVie() { vies++; };
  //void subVie() { vies--; };
  //void addScore(int points) { score += points; };

private:
  Level *level;
  Vaisseau *vaisseau;
  unsigned int vies;
  unsigned int numLevel;
  unsigned int score;
};

#endif
