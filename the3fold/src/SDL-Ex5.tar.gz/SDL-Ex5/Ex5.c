// -=(the3fold)=-
//
// Ex5.c
// Exemple n�5 d'utilisation de SDL
// Affiche le traditionnel "Hello World !"
//

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>

unsigned char Quitter = 0;
SDL_Surface *Screen;

// Renvoi une surface contenant le texte "texte" ecrit en
// couleur "fgColor" sur fond de couleur "bgColor" dans la
// police de nom "font_face" et de taille "font_size"
SDL_Surface *Texte(char *texte, char *font_face, short font_size, SDL_Color fgColor, SDL_Color bgColor)
{
  TTF_Font *font;
  SDL_Surface *text;
  
  // Chargement de la police
  font = TTF_OpenFont(font_face, font_size); 
  if (!font) 
    fprintf(stderr, "Impossible de charger la taille %dpt depuis %s: %s\n", font_size, font_face, SDL_GetError());  
  
  // Cr�ation de la surface contenant le texte
  text = TTF_RenderText_Shaded(font, texte, fgColor, bgColor);
  if (text==NULL)
    fprintf(stderr, "Impossible de cr�er la surface contenant le texte : %s\n", SDL_GetError());
  
  // Fermeture de la police
  TTF_CloseFont(font); 

  return text;
}

// Fonction se chargeant de tous les evenements
static void process_events(void)
{
   SDL_Event event;
   while(SDL_PollEvent(&event))
   {
      switch(event.type)
      {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            Quitter = 1;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
	Quitter = 1;
	break;
      }
   }
}

// Initialise SDL
void InitSDL()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr,"Impossible d'initialiser SDL : %s.\n", SDL_GetError());
    exit(-1);
  }
  atexit(SDL_Quit);

  Screen = SDL_SetVideoMode(800, 600, 24, SDL_SWSURFACE | SDL_ANYFORMAT | SDL_FULLSCREEN);

  if(Screen == NULL)
  {
    fprintf(stderr, "Impossible de s�lectionner le mode video 800x600x24 : %s.\n", SDL_GetError());
    exit(-1);
  }

  // Initialise l'affichage de texte
  if (TTF_Init() < 0) 
  {
    fprintf(stderr, "Impossible d'initialiser SDL_TTF: %s\n",SDL_GetError());
    exit(-1);
  }
}

void affichage()
{
  // Affiche la celebre citation
  SDL_Color fg, bg;
  fg.r = 255; fg.g = 255; fg.b = 0;
  bg.r = 0; bg.g = 0; bg.b = 255;
  SDL_Surface *text;
  text = Texte("Hello World !","babelfish.ttf",80, fg, bg);

  if(SDL_BlitSurface(text, NULL, Screen, NULL) < 0)
    fprintf(stderr, "Erreur de BlitSurface : %s\n", SDL_GetError());

  SDL_FreeSurface(text);
  
  SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

int main(int argc, char *argv[], char *env[])
{
  InitSDL();

  while(!Quitter)
  {
    affichage();
    process_events();
  }

  return 0;
}
