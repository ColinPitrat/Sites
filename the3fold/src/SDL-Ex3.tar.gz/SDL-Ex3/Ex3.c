// -=(the3fold)=-
//
// Ex3.c
// Exemple n�3 d'utilisation de SDL
// Charge et affiche une image au format BMP
//

#include <SDL/SDL.h>
#include <stdio.h>

unsigned char Quitter = 0;
SDL_Surface *screen;

SDL_Surface *loadBMP(char *fileName)
{
  SDL_Surface *image;

  image = SDL_LoadBMP(fileName);
  if(image == NULL)
  {
    fprintf(stderr, "Impossible de charger %s : %s\n", fileName, SDL_GetError());
    return NULL;
  }

  return image;
}

static void process_events(void)
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_ESCAPE:      
          Quitter = 1;
          break;
        default:
          break;
        }
        break;
      case SDL_QUIT:
        Quitter = 1;
        break;
    }
  }
}

void InitSDL()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr,"Impossible d'initialiser SDL : %s.\n", SDL_GetError());
    exit(-1);
  }
  atexit(SDL_Quit);

  screen = SDL_SetVideoMode(320, 240, 24, SDL_SWSURFACE | SDL_ANYFORMAT);

  if(screen == NULL)
  {
    fprintf(stderr,"Impossible de s�lectionner le mode video 320x240x24 : %s.\n", SDL_GetError());
    exit(-1);
  }

  SDL_WM_SetCaption("-=(the3fold)=- Exemple 3", NULL);
}

int main(int argc, char *argv[], char *env[])
{
  InitSDL();

  SDL_Surface *image;   
  image = loadBMP("image.bmp");

  if(SDL_BlitSurface(image, NULL, screen, NULL) < 0)
    fprintf(stderr, "Erreur de BlitSurface : %s\n", SDL_GetError());

  while(!Quitter)
  {
    SDL_UpdateRect(screen, 0, 0, image->w, image->h);
    process_events();
  }

  SDL_FreeSurface(image);

  return 0;
}
