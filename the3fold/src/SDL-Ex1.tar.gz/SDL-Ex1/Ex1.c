// -=(the3fold)=-
//
// Ex1.c
// Exemple n�1 d'utilisation de SDL
// Initialise SDL puis le quitte
//

#include <SDL/SDL.h>
#include <stdio.h>

int main()
{
   printf("Initialisation de SDL.\n");
   if((SDL_Init(SDL_INIT_VIDEO) == -1))
   {
      printf("Impossible d'initaliser SDL : %s.\n", SDL_GetError());
      return -1;
   }
   printf("SDL est initialis�.\n");

   printf("Quitte SDL.\n");
   SDL_Quit();

   return 0;
}
