#ifndef _STARWARS_ARMES
#define _STARWARS_ARMES

#include "animPict.h"

struct projectile
{
  projectile *previous;
  projectile *next;
  unsigned int type;
  int x,y;                      // Position actuelle � l'�cran du projectile
  char dx,dy;                   // Vitesse actuelle du projectile
  unsigned char mort;           // Nombre d'images avant la fin de l'explosion
};

struct arme
{
  unsigned char degats;         // Degats caus�s par l'arme
  unsigned int x_init, y_init;  // Position de d�part (par rapport au coin superieur gauche du vaisseau)
  char dx_init, dy_init;        // Vitesse initiale (peut ou non s'ajouter � celle du vaisseau)
  unsigned char lumique;        // Si la vitesse initiale s'ajoute � celle du vaisseau ou non (arme photonique ou non)
  unsigned char loadTime;       // Temps de chargement de l'arme
  unsigned char decharge;       // Peut on tirer avec cette arme ?
  animPict *skin;
  animPict *destruct;
};

#endif
