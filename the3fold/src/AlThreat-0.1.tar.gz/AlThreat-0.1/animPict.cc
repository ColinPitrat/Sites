#include "animPict.h"

animPict::animPict(int num, char **fichiers, int d)
{
  finished = 0;
  animPos = 0;
  nbPict = num;
  delay = d;
  Pictures = new SDL_Surface*[nbPict];
  int i=0;

  // On charge toutes les images
  for(i=0; i<nbPict; i++)
  {
    Pictures[i] = IMG_Load(fichiers[i]);
    if(Pictures[i] == NULL)
    {
      std::cerr << "Erreur : Impossible de charger " << fichiers[i] << " : " << SDL_GetError() << std::endl;
      break;
    }
  }
  nbPict = i;

  nextTime = SDL_GetTicks() + delay;
}

animPict::animPict(int num, SDL_Surface **images, int d)
{
  finished = 0;
  animPos = 0;
  nbPict = num;
  delay = d;
  Pictures = new SDL_Surface*[nbPict];
  int i=0;

  // On charge toutes les images
  for(i=0; i<nbPict; i++)
  {
    Pictures[i] = images[i];
    if(Pictures[i] == NULL)
    {
      std::cerr << "Erreur : Une image pass�e pour une animation est vide\n";
      break;
    }
  }
  nbPict = i;

  nextTime = SDL_GetTicks() + delay;
}

animPict::animPict(char *fichier)
{
  finished = 0;
  animPos = 0;

  FILE *F;
  if((F = fopen(fichier,"r")) == NULL)
  {
    std::cerr << "Erreur : Impossible d'ouvrir le fichier " << fichier << std::endl;
    return;
  }

  if(fscanf(F,"%d %d",&nbPict,&delay) < 2)
  {
    std::cerr << "Erreur : Impossible de lire dans le fichier " << fichier << std::endl;
    return;
  }

  Pictures = new SDL_Surface*[nbPict];
  for(int i = 0; i < nbPict; i++)
  {
    char filename[255];
    if(fscanf(F,"%s",filename) < 1)
    {
      std::cerr << "Erreur : Impossible de lire dans le fichier " << fichier << std::endl;
      break;
    }

    Pictures[i] = IMG_Load(filename);
    if(Pictures[i] == NULL)
    {
      std::cerr << "Erreur : Impossible de charger " << filename << " : " << SDL_GetError() << std::endl;
      break;
    }
  }

  nextTime = SDL_GetTicks() + delay;
}

animPict::~animPict()
{
  for(int i = 0; i < nbPict; i++)
  {
    SDL_FreeSurface(Pictures[i]);
  }
}

void animPict::SetColorKey(Uint32 flags, Uint32 key)
{
  for(int i=0; i<nbPict; i++)
  {
    SDL_SetColorKey(Pictures[i], flags, key);
  }
}

void animPict::SetAlpha(Uint32 flags, Uint32 alpha)
{
  for(int i=0; i<nbPict; i++)
  {
    SDL_SetAlpha(Pictures[i], flags, alpha);
  }
}

void animPict::animer()
{
  if(SDL_GetTicks() >= nextTime)
  {
    animPos++;
    if(animPos >= nbPict)
    {
      animPos -= nbPict;
      finished = 1;
    }
    nextTime = SDL_GetTicks() + delay;
  }
}
