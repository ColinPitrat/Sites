#include "Game.h"

extern Game Actuel;

// Cr�e une nouvelle partie
void NewGame()
{
  FILE *F;
  char *pvDesc = "preview";
  char *vaisDesc = "proprietes";

  char *liste="vaisseaux/vaisseaux.lst";

  if((F = fopen(liste,"r")) == NULL)
  {
    std::cerr << "Erreur : Impossible d'ouvrir le fichier " << liste << std::endl;
    exit(1);
  }

  int nbVaisseaux;
  unsigned char Selection = 0;

  if(fscanf(F,"%d",&(nbVaisseaux)) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << liste << std::endl;
    exit(1);
  }

  animPict **previews;
  previews = new animPict*[nbVaisseaux];
  char (*vaissNom)[255];
  char (*repert)[255];
  vaissNom = new char[nbVaisseaux][255];
  repert = new char[nbVaisseaux][255];
  char **nomsVaisseaux;
  char **repertoires;
  nomsVaisseaux = new char*[nbVaisseaux];
  repertoires = new char*[nbVaisseaux];
  int i;
  for(i = 0; i < nbVaisseaux; i++)
  {
    if(fscanf(F,"%s",vaissNom[i]) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << liste << std::endl;
      exit(1);
    }
    nomsVaisseaux[i] = &vaissNom[i][0];

    if(fscanf(F,"%s",repert[i]) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << liste << std::endl;
      exit(1);
    }
    repertoires[i] = &repert[i][0];

    int j = strlen(repert[i]);
    int a;
    for(a = 0; a < strlen(pvDesc)+1; a++)
    {
      repert[i][j+a] = pvDesc[a];
    }

    previews[i] = new animPict(repert[i]);
  }

  i = 0;
  do
  {
    SDL_Event event;
    while(SDL_PollEvent(&event))
    {
      switch(event.type)
      {
        case SDL_KEYDOWN:
          switch(event.key.keysym.sym)
          {
            case SDLK_ESCAPE:
            case SDLK_RETURN:
              Selection = 1;
              break;
            case SDLK_RIGHT:
              if(++i == nbVaisseaux)
                i = 0;
              break;
            case SDLK_LEFT:
              if(--i < 0)
                i = nbVaisseaux - 1;
              break;
            default:
              break;
          }
          break;
        default:
          break;
      }
    }
    SDL_Surface *Screen = SDL_GetVideoSurface();
    SDL_Surface *Fond = loadImage("images/Choix.png");
    SDL_BlitSurface(Fond, NULL, Screen, NULL);

    SDL_Color color;
    color.r = 255; color.g = 0; color.b = 0;
    SDL_Surface *nomTxt = Texte(nomsVaisseaux[i], "babelfish.ttf", 60, color);
    SDL_Rect dst, dst2;
    dst.x = 250;
    dst.y = 200;
    dst.w = previews[i]->getPicture()->w;
    dst.h = previews[i]->getPicture()->h;
    dst2.x = 500 - nomTxt->w / 2;
    dst2.y = 550 - nomTxt->h / 2;
    dst2.w = nomTxt->w;
    dst2.h = nomTxt->h;
    SDL_BlitSurface(previews[i]->getPicture(), NULL, Screen, &dst);
    SDL_BlitSurface(nomTxt, NULL, Screen, &dst2);

    SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
    SDL_FreeSurface(Fond);
    SDL_FreeSurface(nomTxt);
  }while(!Selection);

  int j = strlen(repert[i]) - strlen(pvDesc);
  int a;
  for(a = 0; a < strlen(vaisDesc)+1; a++)
  {
    repert[i][j+a] = vaisDesc[a];
  }

  for(j = 0; j < nbVaisseaux; j++)
    delete previews[j];
  delete[] previews;
  delete[] vaissNom;
  delete[] nomsVaisseaux;

  if((F = fopen(repertoires[i],"r")) == NULL)
  {
    std::cerr << "Erreur : Impossible d'ouvrir le fichier " << repertoires[i] << std::endl;
    exit(1);
  }

  char filename[255];
  if(fscanf(F,"%s",filename) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
    exit(1);
  }
  Actuel.vaisseau.skin = new animPict(filename);

  if(fscanf(F,"%s",filename) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
    exit(1);
  }
  Actuel.vaisseau.destruct = new animPict(filename);

  if(fscanf(F,"%d %d",&(Actuel.vaisseau.largeur),&(Actuel.vaisseau.hauteur)) < 2)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
    exit(1);
  }

  if(fscanf(F,"%d %d",&(Actuel.vaisseau.vitesse),&(Actuel.vaisseau.energieMax)) < 2)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
    exit(1);
  }

  delete[] repert;
  delete[] repertoires;

  // Chargement des armes disponibles
  if(fscanf(F,"%d",&(Actuel.vaisseau.nbTypesArmes)) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
    exit(1);
  }

  char filename2[255];
  Actuel.vaisseau.armes = new arme[Actuel.vaisseau.nbTypesArmes];
  for(i = 0; i < Actuel.vaisseau.nbTypesArmes; i++)
  {
    if(fscanf(F,"%s",filename) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << repertoires[i] << std::endl;
      exit(1);
    }

    FILE *F2;
    if((F2 = fopen(filename,"r")) == NULL)
    {
      std::cerr << "Erreur : Impossible d'ouvrir le fichier " << filename << std::endl;
      exit(1);
    }

    if(fscanf(F2,"%d %d %d %d %d %d %d",&(Actuel.vaisseau.armes[i].degats), &(Actuel.vaisseau.armes[i].x_init), &(Actuel.vaisseau.armes[i].y_init), &(Actuel.vaisseau.armes[i].dx_init), &(Actuel.vaisseau.armes[i].dy_init), &(Actuel.vaisseau.armes[i].lumique), &(Actuel.vaisseau.armes[i].loadTime)) < 7)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    Actuel.vaisseau.armes[i].decharge = 0;

    if(fscanf(F2,"%s",filename2) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    Actuel.vaisseau.armes[i].skin = new animPict(filename2);
    
    if(fscanf(F2,"%s",filename2) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    Actuel.vaisseau.armes[i].destruct = new animPict(filename2);
  }

  // Statistiques de d�part
  Actuel.vies = 2;
  Actuel.level = 1;
  Actuel.bouclier = 0;
  Actuel.pos = 0;
  Actuel.arme = 1;
  Actuel.energie = Actuel.vaisseau.energieMax;
  Actuel.score = 0;
  Actuel.bombes = 0;
  Actuel.x = 0;
  Actuel.y = 275;
}
