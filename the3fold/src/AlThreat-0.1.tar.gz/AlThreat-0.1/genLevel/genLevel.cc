#include <stdlib.h>
#include <iostream>
#include <fstream>
#include <string>

#define HEIGHT 600

int main()
{
  long int seed, nbTypeAst, levelLength, distAst, xvitMax, yvitMax;

  std::cout << "Entrez la graine pour la g�n�ration du level : ";
  std::cin >> seed;
  std::cout << "Entrez la longueur d�sir�e pour le level : ";
  std::cin >> levelLength;
  std::cout << "Entrez la distance max entre 2 asteroides : ";
  std::cin >> distAst;
  std::cout << "Entrez la vitesse horizontale maximale des asteroides : ";
  std::cin >> xvitMax;
  std::cout << "Entrez la vitesse verticale maximale des asteroides : ";
  std::cin >> yvitMax;
  if(!std::cin.good())
  {
    std::cerr << "Erreur lors de la saisie.\n";
    return 1;
  }

  std::ofstream fichier;
  fichier.open("level.txt", std::ios::out | std::ios::trunc);
  if(!fichier)
  {
    std::cerr << "Impossible d'ouvrir le fichier.\n";
    return 1;
  }

  srandom(seed);
  long int pos = 0;
  long int delta = 0;
  long int nbAst = 0;
  while(pos < levelLength)
  {
    delta = random() % distAst;
    pos += delta;
    fichier << pos << " " << random() % 600 << " " << (random() % (xvitMax - 1)) + 1 << " " << (random() % (2 *yvitMax)) - yvitMax << std::endl;
    nbAst++;
  }
  std::cout << "Le level a �t� cr�� avec " << nbAst << " asteroides.";
  return 0;
}
