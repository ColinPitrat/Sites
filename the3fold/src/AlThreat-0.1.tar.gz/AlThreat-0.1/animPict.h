#ifndef _ANIMATED_PICTURES
#define _ANIMATED_PICTURES

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <iostream>

class animPict
{
public:
  animPict(int num, char **fichiers, int delay);
  animPict(int num, SDL_Surface **images, int delay);
  animPict(char *filename);
  ~animPict();
  void SetColorKey(Uint32 flags, Uint32 key);
  void SetAlpha(Uint32 flags, Uint32 alpha);
  unsigned char fini() { return finished; };
  SDL_Surface *getPicture() { animer(); return Pictures[animPos % nbPict]; };
  SDL_Surface *getPicture(int num) { return Pictures[num % nbPict]; };
  int getNbPictures() { return nbPict; };
  void animer();
private:
  SDL_Surface **Pictures;
  int nbPict;
  int animPos;
  int delay;
  unsigned char finished;
  Uint32 nextTime;
};

#endif
