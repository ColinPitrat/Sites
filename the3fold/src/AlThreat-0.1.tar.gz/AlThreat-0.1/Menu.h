#ifndef _STARWARS_MENU
#define _STARWARS_MENU

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graphics.h"
#include "animPict.h"
#include "Game.h"
#include "Armes.h"

// Nombre d'items dans le menu
#define NB_OPT 5 

// Fonctions pour les options
static void options_events();
void affichage_options();
void Options();

// Fonctions pour les cr�dits
static void credits_events(char &FinCredits);
void affichage_credits();
void Credits();

// Fonctions pour le menu
static void menu_events(char &Selected);
void affichage_menu(char selected);
unsigned char Menu(unsigned char nosound);

#endif
