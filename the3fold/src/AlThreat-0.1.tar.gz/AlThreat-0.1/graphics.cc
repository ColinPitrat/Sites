#include "graphics.h"

void InitSDL(unsigned char nosound, unsigned char fullscreen)
{
  if(!nosound)
  {
    if(SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0)
    {
      std::cerr << "Impossible d'initialiser SDL : " << SDL_GetError() << std::endl;
      exit(-1);
    }
  }
  else
  {
    if(SDL_Init(SDL_INIT_VIDEO) < 0)
    {
      std::cerr << "Impossible d'initialiser SDL : " << SDL_GetError() << std::endl;
      exit(-1);
    }
  }
  atexit(SDL_Quit);

  SDL_ShowCursor(SDL_DISABLE);

  SDL_Surface *Screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, DEFAULT_BPP, (fullscreen ? SDL_FULLSCREEN : 0) | SDL_HWSURFACE | SDL_ANYFORMAT | SDL_DOUBLEBUF | SDL_HWACCEL);

  if(Screen == NULL)
  {
    std::cerr << "Impossible de s�lectionner le mode video" << SCREEN_WIDTH << "x" << SCREEN_HEIGHT << "x" << DEFAULT_BPP << " : " << SDL_GetError() << std::endl;
    SDL_Quit();
    exit(-1);
  }

  if((Screen->flags & SDL_DOUBLEBUF) != SDL_DOUBLEBUF)
    std::cout << "Le double buffering n'est pas disponible." << std::endl;

  if(!nosound)
  {
    if(Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 1024) == -1)
    {
      std::cerr << "Impossible d'ouvrir le canal audio : " << Mix_GetError() << std::endl;
      exit(-1);
    }
  }

  SDL_EnableUNICODE(1);
  SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL);

  if (TTF_Init() < 0) 
  {
    std::cerr << "Impossible d'initialiser SDL_TTF : " << SDL_GetError() << std::endl;
    exit(-1);
  }

  SDL_WM_SetCaption ("AlThreat", NULL);
}

void putpixel(SDL_Surface *surface, int x, int y, Uint32 pixel)
{
  int bpp = surface->format->BytesPerPixel;
  Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

  switch(bpp) 
  {
    case 1:
      *p = pixel;
      break;
    case 2:
      *(Uint16 *)p = pixel;
      break;
    case 3:
      if(SDL_BYTEORDER == SDL_BIG_ENDIAN) 
      {
        p[0] = (pixel >> 16) & 0xff;
        p[1] = (pixel >> 8) & 0xff;
        p[2] = pixel & 0xff;
      } 
      else 
      {
        p[0] = pixel & 0xff;
        p[1] = (pixel >> 8) & 0xff;
        p[2] = (pixel >> 16) & 0xff;
      }
      break;
    case 4:
      *(Uint32 *)p = pixel;
      break;
  }
}

Uint32 getpixel(SDL_Surface *surface, int x, int y)
{
  int bpp = surface->format->BytesPerPixel;
  Uint8 *p = (Uint8 *)surface->pixels + y * surface->pitch + x * bpp;

  switch(bpp) 
  {
    case 1:
      return *p;
    case 2:
      return *(Uint16 *)p;
    case 3:
      if(SDL_BYTEORDER == SDL_BIG_ENDIAN)
        return p[0] << 16 | p[1] << 8 | p[2];
      else
        return p[0] | p[1] << 8 | p[2] << 16;
    case 4:
      return *(Uint32 *)p;
    default:
      return 0;
  }
}

SDL_Surface *loadImage(char *fileName)
{
  SDL_Surface *image;

  image = IMG_Load(fileName);
  if(image == NULL)
  {
    std::cerr << "Impossible de charger " << fileName << " : " << SDL_GetError() << std::endl;
    return NULL;
  }

  return image;
}

SDL_Surface *Texte(char *texte, char *font_face, short font_size, SDL_Color fgColor)
{
  TTF_Font *font;
  SDL_Surface *text;

  font = TTF_OpenFont(font_face, font_size); // Chargement de la police
  if (!font) 
    std::cerr << "Impossible de charger la taille " << font_size << "pt depuis " << font_face << " : " << SDL_GetError() << std::endl;

  text = TTF_RenderText_Blended(font, texte, fgColor);

  // Fermeture de la police
  TTF_CloseFont(font); 

  return text;
}
