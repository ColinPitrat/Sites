#include <iostream>
#include <string>
#include <unistd.h>
#include "Game.h"
#include "Menu.h"
#include "Level.h"

#define NB_ETOILES 500
#define ETOILES_VIT_MIN 5
#define ETOILES_VIT_MAX 2

#define MAX(x,y) (((x) > (y)) ? (x) : (y))
#define MIN(x,y) (((x) < (y)) ? (x) : (y))

Game Actuel;                      // Description du jeu actuel
element *elements;                // Types d'�l�ments de d�cor disponibles
descLevel level;                  // Description du level actuel
projectile *Projectiles = NULL;   // Liste des projectiles actuellement � l'�cran
stars etoiles[NB_ETOILES];        // Etoiles composant le fond

// vel && 1 => avance
// vel && 2 => recule
// vel && 4 => monte
// vel && 8 => descend
static void jeu_events(unsigned char &vel, unsigned char &shoot, unsigned char &FinJeu)
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            FinJeu = 1;
            break;
          case SDLK_UP:
            if(!(vel & 4))
              vel += 4;
            break;
          case SDLK_DOWN:
            if(!(vel & 8))
              vel += 8;
            break;
          case SDLK_RIGHT:
            if(!(vel & 1))
              vel += 1;
            break;
          case SDLK_LEFT:
            if(!(vel & 2))
              vel += 2;
            break;
          case SDLK_SPACE:
            shoot = 1;
            break;
          default:
            break;
        }
        break;
      case SDL_KEYUP:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            FinJeu = 1;
            break;
          case SDLK_UP:
            if(vel & 4)
              vel -= 4;
            break;
          case SDLK_DOWN:
            if(vel & 8)
              vel -= 8;
            break;
          case SDLK_RIGHT:
            if(vel & 1)
              vel -= 1;
            break;
          case SDLK_LEFT:
            if(vel & 2)
              vel -= 2;
            break;
          case SDLK_SPACE:
            shoot = 0;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        FinJeu = 1;
        break;
      default:
        break;
    }
  }
}

// Affiche l'aide sur la ligne de commande
void info(std::string appname)
{
  std::cout << "Usage : " << appname << " <options>\n";
  std::cout << "  Options :\n\t-h : Affiche ce message d'aide (help)\n\t-f : Plein �cran (fullscreen)\n\t-m : Pas de son (mute)\n";
}

// Affiche le fond d'�toile d�filant
void background(SDL_Surface *Screen)
{
  int i;
  for(i = 0; i < NB_ETOILES; i++)
  {
    etoiles[i].time--;
    if(etoiles[i].time == 0)
    {
      etoiles[i].x--;
      etoiles[i].time = etoiles[i].dx;
      if(etoiles[i].x <= 0)
      {
        etoiles[i].x = Screen->w; 
        etoiles[i].dx = random() % ETOILES_VIT_MIN + ETOILES_VIT_MAX;
        etoiles[i].y = random() % Screen->h; 
        etoiles[i].color = SDL_MapRGB(Screen->format, random() % 255, random() % 255, random() % 255); 
      }
    }
    putpixel(Screen, etoiles[i].x, etoiles[i].y, etoiles[i].color);
  }
}

// Charge un niveau 
unsigned char LoadLevel(unsigned char lvl)
{
  SDL_Surface *Screen = SDL_GetVideoSurface();
  int i;
  for(i = 0; i < NB_ETOILES; i++)
  {
    etoiles[i].x = random() % Screen->w; 
    etoiles[i].dx = random() % ETOILES_VIT_MIN + ETOILES_VIT_MAX; 
    etoiles[i].time = etoiles[i].dx;
    etoiles[i].y = random() % Screen->h; 
    etoiles[i].color = SDL_MapRGB(Screen->format, random() % 255, random() % 255, random() % 255); 
  }

  char *levelsFile="levels/levels.lst";
  FILE *F;

  if((F = fopen(levelsFile,"r")) == NULL)
  {
    std::cerr << "Erreur : Impossible d'ouvrir le fichier " << levelsFile << std::endl;
    exit(1);
  }

  unsigned int nbLevels;
  if(fscanf(F,"%d",&nbLevels) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << levelsFile << std::endl;
    exit(1);
  }

  if(lvl > nbLevels)
    return 1;

  char filename[255];
  for(i = 0; i < lvl; i++)
  {
    if(fscanf(F,"%s",filename) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << levelsFile << std::endl;
      exit(1);
    }
  }

  if((F = fopen(filename,"r")) == NULL)
  {
    std::cerr << "Erreur : Impossible d'ouvrir le fichier " << filename << std::endl;
    exit(1);
  }

  if(fscanf(F,"%d",&(level.end)) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
    exit(1);
  }

  if(fscanf(F,"%s",level.musique) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
    exit(1);
  }

  if(fscanf(F,"%d",&(level.nbTypesElements)) < 1)
  {
    std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
    exit(1);
  }

  // Cr�ation du tableau d'�lements
  elements = new element[level.nbTypesElements];
  for(i = 0; i < level.nbTypesElements; i++)
  {
    if(fscanf(F,"%s",filename) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }

    FILE *F2;
    if((F2 = fopen(filename,"r")) == NULL)
    {
      std::cerr << "Erreur : Impossible d'ouvrir le fichier " << filename << std::endl;
      exit(1);
    }

    if(fscanf(F2,"%d %d %d",&(elements[i].energieMax),&(elements[i].value),&(elements[i].degats)) < 2)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }

    char fichier[255];
    if(fscanf(F2,"%s",fichier) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    elements[i].skin = new animPict(fichier);

    if(fscanf(F2,"%s",fichier) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    elements[i].destruct = new animPict(fichier);
  }

  // Chargement des elements du d�cor
  int nbElements;
  if(fscanf(F,"%d",&(nbElements)) < 1)
  {
    std::cerr << "Erreur: Impossible de lire le nombre d'�l�ments du d�cor dans le fichier " << filename << std::endl;
    exit(1);
  }

  if(nbElements >= 1)
  {
    level.premierElement = new decor;
    if(fscanf(F,"%d %d %d %d %d",&(level.premierElement->type),&(level.premierElement->pos),&(level.premierElement->y),&(level.premierElement->dx),&(level.premierElement->dy)) < 1)
    {
      std::cerr << "Erreur: Impossible de lire un �l�ment du d�cor dans le fichier " << filename << std::endl;
      exit(1);
    }
    level.premierElement->x = Screen->w;
    level.premierElement->energie = elements[level.premierElement->type - 1].energieMax;
    level.premierElement->mort = 0;
    level.premierElement->previous = NULL;
    level.premierElement->next = NULL;
  }
  else
  {
    level.premierElement = NULL;
  }

  decor *elementPrecedent = level.premierElement;
  for(i = 1; i < nbElements; i ++)
  {
    elementPrecedent->next = new decor;
    elementPrecedent->next->previous = elementPrecedent;
    elementPrecedent = elementPrecedent->next;

    if(fscanf(F,"%d %d %d %d %d",&(elementPrecedent->type),&(elementPrecedent->pos),&(elementPrecedent->y),&(elementPrecedent->dx),&(elementPrecedent->dy)) < 1)
    {
      std::cerr << "Erreur : Impossible de lire le fichier " << filename << std::endl;
      exit(1);
    }
    elementPrecedent->x = Screen->w;
    elementPrecedent->energie = elements[elementPrecedent->type - 1].energieMax;
    elementPrecedent->mort = 0;
    elementPrecedent->next = NULL;
  }

  Actuel.pos = 0;
  return 0;
}

void affichage(SDL_Surface *Screen, SDL_Rect *rect)
{
  SDL_Rect vaissPos;
  vaissPos.x = rect->x;
  vaissPos.y = rect->y;
  vaissPos.w = rect->w;
  vaissPos.h = rect->h;
      // Affiche tout le d�cor
      {
        decor *elementActuel = level.premierElement;
        SDL_Rect actPos;
        while((elementActuel != NULL) && (elementActuel->pos < Actuel.pos))
        {
          SDL_Surface *image;
          if(elementActuel->mort)
          {
            image = elements[elementActuel->type - 1].destruct->getPicture(elementActuel->mort--);
            if(elementActuel->mort == 0)
            {
              if(elementActuel->next != NULL)
                elementActuel->next->previous = elementActuel->previous;
              if(elementActuel->previous != NULL)
                elementActuel->previous->next = elementActuel->next;
              else
                level.premierElement = elementActuel->next;
              delete elementActuel;
            }
          }
          else
            image = elements[elementActuel->type - 1].skin->getPicture();
          actPos.x = elementActuel->x;
          actPos.y = elementActuel->y;
          actPos.w = image->w;
          actPos.h = image->h;
          SDL_BlitSurface(image, NULL, Screen, &actPos);
          if((elementActuel->x + image->w < 0) || (elementActuel->y + image->h < 0) || (elementActuel->y > Screen->h) || (elementActuel->x > Screen->w))
          {
            if(elementActuel->next != NULL)
              elementActuel->next->previous = elementActuel->previous;
            if(elementActuel->previous != NULL)
              elementActuel->previous->next = elementActuel->next;
            else
              level.premierElement = elementActuel->next;
            delete elementActuel;
          }
          elementActuel->x -= elementActuel->dx;
          elementActuel->y -= elementActuel->dy;
          elementActuel = elementActuel->next;
        }
      }

      // Affichage des projectiles
      {
        projectile *projectileActuel = Projectiles;
        SDL_Rect actPos;
        while(projectileActuel != NULL)
        {
          SDL_Surface *image;
          if(projectileActuel->mort)
          {
            image = Actuel.vaisseau.armes[projectileActuel->type].destruct->getPicture(projectileActuel->mort--);
            if(projectileActuel->mort == 0)
            {
              if(projectileActuel->next != NULL)
                projectileActuel->next->previous = projectileActuel->previous;
              if(projectileActuel->previous != NULL)
                projectileActuel->previous->next = projectileActuel->next;
              else
                Projectiles = projectileActuel->next;
              delete projectileActuel;
            }
          }
          else
            image = Actuel.vaisseau.armes[projectileActuel->type].skin->getPicture();

          actPos.x = projectileActuel->x;
          actPos.y = projectileActuel->y;
          actPos.w = image->w;
          actPos.h = image->h;
          SDL_BlitSurface(image, NULL, Screen, &actPos);
          if((projectileActuel->x > Screen->w) || (projectileActuel->y + image->h < 0) || (projectileActuel->y > Screen->h) || (projectileActuel->x + image->w < 0))
          {
            if(projectileActuel->next != NULL)
              projectileActuel->next->previous = projectileActuel->previous;
            if(projectileActuel->previous != NULL)
              projectileActuel->previous->next = projectileActuel->next;
            else
              Projectiles = projectileActuel->next;
            delete projectileActuel;
          }
          if(!projectileActuel->mort)
          {
            projectileActuel->x += projectileActuel->dx;
            projectileActuel->y += projectileActuel->dy;
          }
          projectileActuel = projectileActuel->next;
        }
      }

      // Gestion des collisions
      {
        decor *elementActuel = level.premierElement;
        while((elementActuel != NULL) && (elementActuel->pos < Actuel.pos) && (!elementActuel->mort))
        {
          projectile *projectileActuel = Projectiles;
          SDL_Surface *elementImage = elements[elementActuel->type - 1].skin->getPicture();
          while(projectileActuel != NULL && (!projectileActuel->mort))
          {
            SDL_Surface *projectileImage = Actuel.vaisseau.armes[projectileActuel->type].skin->getPicture();
            if(!((elementActuel->x > projectileActuel->x + projectileImage->w) ||
                  (elementActuel->y > projectileActuel->y + projectileImage->h) ||
                  (elementActuel->x + elementImage->w < projectileActuel->x) ||
                  (elementActuel->y + elementImage->h < projectileActuel->y)))
            {
              unsigned char collision = 0;
              for(int i = MAX(elementActuel->x,projectileActuel->x); i < MIN(elementActuel->x + elementImage->w,projectileActuel->x + projectileImage->w); i++)
                for(int j = MAX(elementActuel->y, projectileActuel->y); j < MIN(elementActuel->y + elementImage->h, projectileActuel->y + projectileImage->h); j++)
                {
                  if(getpixel(elementImage, i - elementActuel->x, j - elementActuel->y) && getpixel(projectileImage, i - projectileActuel->x, j - projectileActuel->y))
                    collision = 1;
                }

              if(collision)
              {
                // D�truit le projectile
                projectileActuel->mort = Actuel.vaisseau.armes[projectileActuel->type].destruct->getNbPictures();

                if(elementActuel->energie >= Actuel.vaisseau.armes[projectileActuel->type].degats)
                  elementActuel->energie -= Actuel.vaisseau.armes[projectileActuel->type].degats;
                else
                  elementActuel->energie = 0;

                if(elementActuel->energie == 0)
                {
                  // D�truit l'�l�ment si n�cessaire
                  elementActuel->mort = elements[elementActuel->type - 1].destruct->getNbPictures();

                  Actuel.score += elements[elementActuel->type - 1].value;
                }
              }
            }
            projectileActuel = projectileActuel->next;
          }

          // Controle des collisions avec le vaisseau
          SDL_Surface *image = Actuel.vaisseau.skin->getPicture();
          if(!((elementActuel->x > vaissPos.x + image->w) ||
                (elementActuel->y > vaissPos.y + image->h) ||
                (elementActuel->x + elementImage->w < vaissPos.x) ||
                (elementActuel->y + elementImage->h < vaissPos.y)))
          {
            unsigned char collision = 0;
            for(int i = MAX(elementActuel->x, vaissPos.x); i < MIN(elementActuel->x + elementImage->w, vaissPos.x + image->w); i++)
              for(int j = MAX(elementActuel->y, vaissPos.y); j < MIN(elementActuel->y + elementImage->h, vaissPos.y + image->h); j++)
              {
                if(getpixel(elementImage, i - elementActuel->x, j - elementActuel->y) && getpixel(image, i - vaissPos.x, j - vaissPos.y))
                  collision = 1;
              }

            if(collision)
            {
              // Abime le vaisseau
              if(elements[elementActuel->type - 1].degats < Actuel.energie)
                Actuel.energie -= elements[elementActuel->type - 1].degats;
              else
                Actuel.energie = 0;

              if(Actuel.energie == 0)
              {
                Actuel.vaisseau.mort = Actuel.vaisseau.destruct->getNbPictures();
              }
              // D�truit l'�l�ment 
              elementActuel->mort = elements[elementActuel->type - 1].destruct->getNbPictures();

              // On ne monte quand m�me pas le Score ...
              //Actuel.score += elements[elementActuel->type - 1].value;
            }
          }
          elementActuel = elementActuel->next;
        }
      }

      // Affiche les informations (Score, Level, Energie, Bombes ...)
      {
        char infos[255];
        char temp[10];
        strcpy (infos, "Level : ");
        sprintf (temp, "%d", Actuel.level);
        strcat (infos, temp);
        strcat (infos, "   Score : ");
        sprintf (temp, "%d", Actuel.score);
        strcat (infos, temp);
        strcat (infos, "   Vies : ");
        sprintf (temp, "%d", Actuel.vies);
        strcat (infos, temp);
        strcat (infos, "   Energie : ");

        SDL_Color color;
        color.r = 255; color.g = 255; color.b = 0;
        SDL_Surface *Infos = Texte(infos, "babelfish.ttf", 40, color);
        SDL_BlitSurface(Infos, NULL, Screen, NULL);

        // Affiche la barre d'�nergie
        SDL_Rect ligne;
        ligne.x = Infos->w;
        ligne.y = 5;
        ligne.w = 101;
        ligne.h = 1;
        SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
        ligne.y = 25;
        SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
        ligne.y = 5;
        ligne.w = 1;
        ligne.h = 21;
        SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
        ligne.x = Infos->w + 101;
        SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 255, 0, 0));
        ligne.x = Infos->w + 1;
        ligne.y = 6;
        ligne.w = (100 * Actuel.energie) / Actuel.vaisseau.energieMax;
        ligne.h = 19;
        SDL_FillRect(Screen, &ligne, SDL_MapRGB(Screen->format, 0, 0, 255));

        SDL_FreeSurface(Infos);
      }
}

void Jeu(unsigned char nosound)
{
  unsigned char FinJeu = 0;
  SDL_Surface *Screen = SDL_GetVideoSurface();
  Mix_Music *musique = NULL; 
  FinJeu = LoadLevel(Actuel.level);

  Uint32 beginning = SDL_GetTicks();
  Uint32 frames = 0;
  while(!FinJeu)
  {
    if(!nosound)
    {
      Mix_FadeOutMusic(1000);
      if(musique) Mix_FreeMusic(musique);
      musique = Mix_LoadMUS(level.musique);
      if(!musique)
      {
        std::cerr << "Impossible de charger la musique du menu : " << Mix_GetError() << std::endl;
        exit(-1);
      }

      Mix_PlayMusic(musique, -1);
    }

    SDL_Rect vaissPos;
    vaissPos.x = Actuel.x;
    vaissPos.y = Actuel.y;
    vaissPos.w = Actuel.vaisseau.largeur;
    vaissPos.h = Actuel.vaisseau.hauteur;
    unsigned char vel = 0;
    unsigned char shoot = 0;
    Uint32 debut = SDL_GetTicks();

    while((!FinJeu) && (Actuel.pos < level.end))
    {
      // Efface l'�cran
      SDL_FillRect(Screen, NULL, 0);

      // Affiche le fond �toil�
      background(Screen);

      // Affiche le vaisseau
      if(!Actuel.vaisseau.mort)
        SDL_BlitSurface(Actuel.vaisseau.skin->getPicture(), NULL, Screen, &vaissPos);
      else
      {
        SDL_BlitSurface(Actuel.vaisseau.destruct->getPicture(Actuel.vaisseau.mort--), NULL, Screen, &vaissPos);
        if(!Actuel.vaisseau.mort)
          FinJeu = 1;
      }

      affichage(Screen, &vaissPos);

      jeu_events(vel, shoot, FinJeu);

      // Anime le vaisseau
      if(vel & 1 && vaissPos.x < SCREEN_WIDTH - vaissPos.w)
        vaissPos.x += Actuel.vaisseau.vitesse;
      if(vel & 2 && vaissPos.x > 0)
        vaissPos.x -= Actuel.vaisseau.vitesse;
      if(vel & 4 && vaissPos.y > 0)
        vaissPos.y -= Actuel.vaisseau.vitesse;
      if(vel & 8 && vaissPos.y < SCREEN_HEIGHT - vaissPos.h)
        vaissPos.y += Actuel.vaisseau.vitesse;

      // Lancement d'un projectile si n�cessaire
      if(shoot)
      {
        for(int i = 0; i < Actuel.vaisseau.nbTypesArmes; i++)
        {
          if(!Actuel.vaisseau.armes[i].decharge)
          {
            projectile *nouveau;
            if(Projectiles != NULL)
            {
              nouveau = Projectiles;
              while(nouveau->next != NULL)
                nouveau = nouveau->next;
              nouveau->next = new projectile;
              nouveau->next->previous = nouveau;
              nouveau = nouveau->next;
            }
            else
            {
              Projectiles = new projectile;
              nouveau = Projectiles;
              nouveau->previous = NULL;
            }
            nouveau->next = NULL;
            nouveau->type = 0;
            nouveau->mort = 0;
            nouveau->x = vaissPos.x + Actuel.vaisseau.armes[nouveau->type].x_init;
            nouveau->y = vaissPos.y + Actuel.vaisseau.armes[nouveau->type].y_init;
            nouveau->dx = Actuel.vaisseau.armes[nouveau->type].dx_init;
            nouveau->dy = Actuel.vaisseau.armes[nouveau->type].dy_init;
            if(!Actuel.vaisseau.armes[nouveau->type].lumique)
            {
              // Gestion des armes non lumiques
              if(vel & 1)
                nouveau->dx += Actuel.vaisseau.vitesse;
              if(vel & 2)
                nouveau->dx -= Actuel.vaisseau.vitesse;
              if(vel & 4)
                nouveau->dy -= Actuel.vaisseau.vitesse;
              if(vel & 8)
                nouveau->dy += Actuel.vaisseau.vitesse;
            }
            Actuel.vaisseau.armes[i].decharge = Actuel.vaisseau.armes[i].loadTime;
          }
        }
      }

      // On recharge les armes qui en ont besoin 
      for(int i = 0; i < Actuel.vaisseau.nbTypesArmes; i++)
        if(Actuel.vaisseau.armes[i].decharge)
          Actuel.vaisseau.armes[i].decharge--;

      // On fait avancer l'�cran
      Actuel.pos++;

      // On attend (pour avoir une vitesse d'execution maximale)
      while(SDL_GetTicks() - debut < 20);
      debut = SDL_GetTicks();

      frames++;
      SDL_Flip(Screen);
    }
    Uint32 end = SDL_GetTicks();
    std::cout << frames << " images en " << ((double)end - beginning) / 1000 << " secondes -> " << (double)frames * 1000 / ((double)end - beginning) << "FPS\n";
    Actuel.level++;
    for(int i = 0; i < level.nbTypesElements; i++)
    {
      delete elements[i].skin;
      delete elements[i].destruct;
    }
    delete[] elements;
    FinJeu = FinJeu ? 1 : LoadLevel(Actuel.level);
  }

  delete Actuel.vaisseau.skin;
  if(!nosound) Mix_FreeMusic(musique);
}

int main(int argc, char *argv[], char *env[])
{
  unsigned char nosound = 0;
  unsigned char fullscreen = 0;

  // Traitement des options
  // -m : pas de son
  // -h : affiche l'aide
  // -f : fullscreen
  {
    char c;
    while ((c = getopt(argc, argv, "mhf")) != -1)
    {
      switch(c)
      {
        case 'm':
          nosound = 1;
          break;
        case 'f':
          fullscreen = 1;
          break;
        case '?':
          std::cerr << "Erreur : Option inconnue `-" << optopt << "'.\n";
          exit(-1);
        case 'h':
        default:
          info(argv[0]);
          exit(0);
      }
    }
  }

  InitSDL(nosound, fullscreen);

  unsigned char Quitter = 0;
  while(!Quitter)
  {
    switch(Menu(nosound))
    {
      case 0:
        Jeu(nosound);
        break;
      case 1:
        //Jeu(nosound);
        break;
      case 4:
        if(!nosound) Mix_FadeOutMusic(1000);
        Quitter = 1;
        break;
      default:
        std::cerr << "Erreur : choix de menu inconnu.\n";
        break;
    }
  }

  if(!nosound) Mix_CloseAudio();
  SDL_Quit();
  return 0;
}
