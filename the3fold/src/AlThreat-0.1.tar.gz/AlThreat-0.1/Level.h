struct decor                    // Liste doublement chain�e d�crivant le niveau actuel
{
  decor *previous;
  decor *next;
  unsigned int type;            // Le type de l'�l�ment de d�cor
  unsigned int pos;             // Position dans le niveau
  int x,y;                      // Position � l'�cran si affich�
  char dx,dy;                   // Vitesses horizontales et verticales
  unsigned int energie;         // Energie
  unsigned char mort;           // Nombre d'images avant la fin de l'explosion si l'�l�ment est en train d'exploser
};

struct element
{
  animPict* skin;
  animPict* destruct;
  unsigned int energieMax;
  unsigned int value;           // Nombre de points accord�s pour la destruction
  unsigned int degats;
};

struct descLevel
{
  decor *premierElement;        // D�but de la liste chain�e d�crivant le niveau
  char musique[255];            // Fond musical du niveau
  unsigned int end;             // Position maximale (fin du niveau)
  unsigned int nbTypesElements;
};

struct stars
{
  unsigned int x,y;             // Position de l'�toile � l'�cran
  unsigned char dx;             // Inverse de la vitesse de l'�toile (vitesse max = 1)
  unsigned char time;           // L'�toile avance quand time = 0
  Uint32 color;                 // Couleur de l'�toile
};
