#ifndef _STARWARS_GAME
#define _STARWARS_GAME

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Armes.h"
#include "graphics.h"
#include "animPict.h"

struct swVaiss
{
  animPict* skin;         // Apparence du vaisseau 
  animPict* destruct;     // Explosion du vaisseau 
  unsigned short int largeur, hauteur;
  unsigned int energieMax;
  unsigned short int vitesse;
  unsigned char mort;

  unsigned char nbTypesArmes;
  arme* armes;            // Armes disponibles
};

struct Game
{
  swVaiss vaisseau;       // Vaisseau choisi

  unsigned char level;    // Level actuel
  unsigned int pos;       // Position dans le niveau
  unsigned int x,y;       // Position � l'�cran
  unsigned char vies;     // Nombre de vies
  unsigned char arme;     // Arme actuelle
  unsigned char energie;  // Energie
  unsigned int score;     // Score actuel
  unsigned int bouclier;  // Temps restant d'invincibilit�
  unsigned char bombes;   // Nombre de bombes disponibles

  projectile *firstProj;  // D�but de la liste chain�e de projectiles
};

void NewGame();

#endif
