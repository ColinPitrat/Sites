#include "Menu.h"

// Traite les evenements des options
static void options_events()
{
}

// Traite les evenements des credits
static void credits_events(unsigned char &FinCredits)
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            FinCredits = 1;
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        FinCredits = 1;
        break;
      default:
        break;
    }
  }
}

// Traite les evenements du menu
static void menu_events(char &Selected)
{
  SDL_Event event;
  while(SDL_PollEvent(&event))
  {
    switch(event.type)
    {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
          case SDLK_ESCAPE:
            Selected = 2*NB_OPT - 1;
            break;
          case SDLK_UP:
            if(--Selected < 0)
              Selected += NB_OPT;
            break;
          case SDLK_DOWN:
            if(++Selected >= NB_OPT)
              Selected -= NB_OPT;
            break;
          case SDLK_RETURN:
            switch(Selected)
            {
              case 0:
                NewGame();
                Selected += NB_OPT;
                break;
              case 1:
                // LoadGame();
                Selected += NB_OPT;
                break;
              case 2:
                Options();
                break;
              case 3:
                Credits();
                break;
              case 4:
                Selected = 2*NB_OPT - 1;
                break;
              default:
                break;
            }
            break;
          default:
            break;
        }
        break;
      case SDL_QUIT:
        Selected = 2*NB_OPT - 1;
        break;
      default:
        break;
    }
  }
}

// Affiche les options
void affichage_options()
{
}

// Affiche les cr�dits
void affichage_credits(SDL_Surface *Fond)
{
  SDL_Surface *Screen = SDL_GetVideoSurface();
  SDL_BlitSurface(Fond, NULL, Screen, NULL);
  SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

// Affiche le menu
void affichage_menu(char Selected, SDL_Surface *Fond, animPict* puce)
{
  SDL_Surface *Screen = SDL_GetVideoSurface();
  SDL_BlitSurface(Fond, NULL, Screen, NULL);

  char *texte[NB_OPT];
  texte[0] = "Nouveau";
  texte[1] = "Charger";
  texte[2] = "Options";
  texte[3] = "Credits";
  texte[4] = "Quitter";

  SDL_Color color;
  color.r = 255; color.g = 255; color.b = 0;

  SDL_Surface *options[NB_OPT];
  for(int i=0; i<NB_OPT; i++)
  {
    if(Selected == i)
      color.r = 0;
    else
      color.r = 255;
    options[i] = Texte(texte[i], "babelfish.ttf", 50, color);
  }

  SDL_Rect dest[NB_OPT];
  SDL_Rect pucedest;
  SDL_Surface *laPuce;
  laPuce = puce->getPicture();
  for(int i = 0; i < NB_OPT; i++)
  {
    dest[i].x = (Screen->w - options[i]->w) / 2;
    dest[i].y = (Screen->h - NB_OPT * options[i]->h - (NB_OPT - 1) * options[i]->h / 2) / 2 + i * options[i]->h + (i - 1) * options[i]->h;
    dest[i].w = options[i]->w; 
    dest[i].h = options[i]->h;
    if(Selected == i)
    {
      pucedest.x = dest[i].x - laPuce->w;
      pucedest.y = dest[i].y + (dest[i].h - laPuce->h) / 2;
      pucedest.w = laPuce->w;
      pucedest.h = laPuce->h;
    }
  }

  for(int i=0; i<NB_OPT; i++)
  {
    SDL_BlitSurface(options[i], NULL, Screen, &dest[i]);
    SDL_BlitSurface(laPuce, NULL, Screen, &pucedest);
  }

  SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

void Options()
{
}

void Credits()
{
  SDL_Surface *Fond = loadImage("images/Credits.png");
  unsigned char FinCredits = 0;
  while(!FinCredits)
  {
    affichage_credits(Fond);
    credits_events(FinCredits);
  }
}

unsigned char Menu(unsigned char nosound)
{
  Mix_Music *musique;
  if(!nosound)
  {
    musique = Mix_LoadMUS("sons/Menusong.ogg");
    if(!musique)
    {
      std::cerr << "Erreur : Impossible de charger la musique du menu : " << Mix_GetError() << std::endl;
      exit(-1);
    }

    Mix_FadeInMusic(musique, -1, 3000);
  }

  char *fichiers[8];
  fichiers[0] = "images/fleche1.png"; 
  fichiers[1] = "images/fleche2.png"; 
  fichiers[2] = "images/fleche3.png"; 
  fichiers[3] = "images/fleche4.png"; 
  fichiers[4] = "images/fleche5.png"; 
  fichiers[5] = "images/fleche6.png"; 
  fichiers[6] = "images/fleche7.png"; 
  fichiers[7] = "images/fleche8.png"; 

  animPict* puce = new animPict(8, fichiers, 100);
  SDL_Surface *Fond = loadImage("images/Menu.png");

  char Selected = 0;
  while(Selected < NB_OPT)
  {
    affichage_menu(Selected, Fond, puce);
    menu_events(Selected);
  }

  delete puce;
  if(!nosound) Mix_FreeMusic(musique);

  return Selected - NB_OPT;
}
