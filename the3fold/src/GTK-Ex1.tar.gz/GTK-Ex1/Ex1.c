// -=(the3fold)=-
//
// Ex1.c
// Exemple n�1 d'utilisation de GTK
// Cr�e une fen�tre vide
//

#include <gtk/gtk.h>
   
int main (int argc, char *argv[])
{
   // Initialisation de GTK
   gtk_init (&argc, &argv);
   
   // Cr�ation de la fen�tre principale
   GtkWidget *mainwin;
   mainwin = gtk_window_new (GTK_WINDOW_TOPLEVEL);

   // Liaison du bouton de fermeture de la fen�tre avec la fin de l'application
   g_signal_connect (GTK_OBJECT(mainwin), "destroy", G_CALLBACK (gtk_main_quit), NULL);
   
   // Affichage de la fen�tre principale
   gtk_widget_show_all (mainwin);
   
   // Boucle principale
   gtk_main ();

   return 0;
}
