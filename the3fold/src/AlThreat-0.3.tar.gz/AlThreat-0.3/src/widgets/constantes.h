#ifndef _T3F_SDL_CONSTS
#define _T3F_SDL_CONSTS

enum Alignement { T3F_LEFT, T3F_CENTER, T3F_RIGHT };
enum Orientation { T3F_HOR, T3F_VERT };

#endif
