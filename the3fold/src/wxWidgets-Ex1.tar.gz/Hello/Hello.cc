/* 
 *  Hello.cc
 *  Utilisation de wxWidgets
 *  exemple 1 - Hello world
 *  -=(the3fold)=-
 *  http://the3fold.free.fr
 */

#include <wx/wx.h>

class HelloApp : public wxApp
{
  virtual bool OnInit();
};

IMPLEMENT_APP(HelloApp)

class HelloFrame : public wxFrame
{
  public:
    HelloFrame(const wxString& title, const wxPoint& pos, const wxSize& size);
    void OnQuit(wxCommandEvent& event);
    void OnAbout(wxCommandEvent& event);
};

enum
{
  ID_Quit = 1,
  ID_About
};

bool HelloApp::OnInit()
{
  HelloFrame *frame = new HelloFrame("Hello World", wxPoint(50, 50), wxSize(450,350));
  frame->Connect(ID_Quit, wxEVT_COMMAND_MENU_SELECTED, (wxObjectEventFunction)& HelloFrame::OnQuit);
  frame->Connect(ID_About, wxEVT_COMMAND_MENU_SELECTED, (wxObjectEventFunction)& HelloFrame::OnAbout);
  frame->Show(true);
  SetTopWindow(frame);
  return true;
}

HelloFrame::HelloFrame(const wxString& title, const wxPoint& pos, const wxSize& size) : wxFrame((wxFrame*)NULL, -1, title, pos, size)
{
  wxMenuBar *menuBar = new wxMenuBar;
  wxMenu *menuFile = new wxMenu;
  menuFile->Append(ID_About, "&About...");
  menuFile->AppendSeparator();
  menuFile->Append(ID_Quit, "E&xit");
  menuBar->Append(menuFile, "&File");
  SetMenuBar(menuBar);
  CreateStatusBar();
  SetStatusText("Demonstration pour wxWidgets");
}

void HelloFrame::OnQuit(wxCommandEvent&)
{
  Close(true);
}

void HelloFrame::OnAbout(wxCommandEvent&)
{
  wxMessageBox("Exemple de Hello World avec wxWidgets\n-=(the3fold)=-\nhttp://the3fold.free.fr", "A propos d'Hello World", wxOK | wxICON_INFORMATION, this);
}
