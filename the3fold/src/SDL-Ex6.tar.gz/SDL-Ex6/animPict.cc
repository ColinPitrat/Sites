#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdio.h>
#include "animPict.h"

animPict::animPict(int num, char **fichiers, int d)
{
  animPos = 0;
  nbPict = num;
  delay = d;
  Pictures = new SDL_Surface*[nbPict];
  int i=0;

  // On charge toutes les images
  for(i=0; i<nbPict; i++)
  {
    Pictures[i] = IMG_Load(fichiers[i]);
    if(Pictures[i] == NULL)
    {
      fprintf(stderr, "Impossible de charger %s : %s\n", fichiers[i], SDL_GetError());
      break;
    }
  }
  nbPict = i;

  nextTime = SDL_GetTicks() + delay;
}

animPict::animPict(int num, SDL_Surface **images, int d)
{
  animPos = 0;
  nbPict = num;
  delay = d;
  Pictures = new SDL_Surface*[nbPict];
  int i=0;

  // On charge toutes les images
  for(i=0; i<nbPict; i++)
  {
    Pictures[i] = images[i];
    if(Pictures[i] == NULL)
    {
      fprintf(stderr, "Erreur : Une image pass�e est vide\n");
      break;
    }
  }
  nbPict = i;

  nextTime = SDL_GetTicks() + delay;
}

animPict::~animPict()
{
  for(int i=0; i<nbPict; i++)
  {
    SDL_FreeSurface(Pictures[i]);
  }
}

void animPict::SetColorKey(Uint32 flags, Uint32 key)
{
  for(int i=0; i<nbPict; i++)
  {
    SDL_SetColorKey(Pictures[i], flags, key);
  }
}

void animPict::SetAlpha(Uint32 flags, Uint32 alpha)
{
  for(int i=0; i<nbPict; i++)
  {
    SDL_SetAlpha(Pictures[i], flags, alpha);
  }
}

void animPict::animer()
{
  if(SDL_GetTicks() >= nextTime)
  {
    animPos++;
    if(animPos >= nbPict)
    {
      animPos -= nbPict;
    }
    nextTime = SDL_GetTicks() + delay;
  }
}
