// -=(the3fold)=-
//
// Ex6.cc
// Exemple n�6 d'utilisation de SDL
// Utilisation de la classe animPict permettant
// de cr�er des animations
//

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <stdio.h>
#include <stdlib.h>
#include "animPict.h"

unsigned char Quitter = 0;
SDL_Surface *Screen;
animPict *test;
animPict *test2;

// Renvoi une surface contenant le texte "texte" ecrit en
// couleur "fgColor" sur fond de couleur "bgColor" dans la
// police de nom "font_face" et de taille "font_size"
SDL_Surface *Texte(char *texte, char *font_face, short font_size, SDL_Color fgColor, SDL_Color bgColor)
{
  TTF_Font *font;
  SDL_Surface *text;
  
  font = TTF_OpenFont(font_face, font_size); // Chargement de la police
  if (!font) 
    fprintf(stderr, "Impossible de charger la taille %dpt depuis %s: %s\n", font_size, font_face, SDL_GetError());  
  
  text = TTF_RenderText_Shaded(font, texte, fgColor, bgColor);
  
  // Fermeture de la police
  TTF_CloseFont(font); 

  return text;
}

// Fonction se chargeant de tous les evenements
static void process_events(void)
{
   SDL_Event event;
   while(SDL_PollEvent(&event))
   {
      switch(event.type)
      {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_ESCAPE:      
          Quitter = 1;
          break;
        default:
          break;
        }
      case SDL_QUIT:
        Quitter = 1;
	break;
      }
   }
}

// Initialise SDL
void InitSDL()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr,"Impossible d'initialiser SDL : %s.\n", SDL_GetError());
    exit(-1);
  }
  atexit(SDL_Quit);

  Screen = SDL_SetVideoMode(160, 160, 24, SDL_SWSURFACE | SDL_ANYFORMAT);

  if(Screen == NULL)
  {
    fprintf(stderr,"Impossible de s�lectionner le mode video 800x600x24 : %s.\n", SDL_GetError());
    SDL_Quit();
    exit(-1);
  }

  printf("Initialisation de la gestion des evenements\n");
  SDL_EnableUNICODE(1);
  SDL_EnableKeyRepeat(SDL_DEFAULT_REPEAT_DELAY, SDL_DEFAULT_REPEAT_INTERVAL + 50);

  if (TTF_Init() < 0) 
  {
    fprintf(stderr, "Impossible d'initialiser SDL_TTF: %s\n",SDL_GetError());
    exit(-1);
  }
}

void affichage()
{
  // Efface tout l'ecran
  SDL_FillRect(Screen, NULL, 0);

  SDL_Surface *image;
  SDL_Rect rect;
  image = test->getPicture();
  rect.x = image->w;
  rect.y = image->h;

  if(SDL_BlitSurface(image, NULL, Screen, NULL) < 0)
    fprintf(stderr, "Erreur de BlitSurface : %s\n", SDL_GetError());

  image = test2->getPicture();
  rect.w = image->w;
  rect.h = image->h;
  rect.x = (rect.x - image->w) / 2;
  rect.y = (rect.y - image->h) / 2;

  if(SDL_BlitSurface(image, NULL, Screen, &rect) < 0)
    fprintf(stderr, "Erreur de BlitSurface : %s\n", SDL_GetError());

  SDL_UpdateRect(Screen, 0, 0, Screen->w, Screen->h);
}

void loadAnims()
{
  char *fichiers[16];
  fichiers[0] = "images/diablo1.png"; 
  fichiers[1] = "images/diablo2.png"; 
  fichiers[2] = "images/diablo3.png"; 
  fichiers[3] = "images/diablo4.png"; 
  fichiers[4] = "images/diablo5.png"; 
  fichiers[5] = "images/diablo6.png"; 
  fichiers[6] = "images/diablo7.png"; 
  fichiers[7] = "images/diablo8.png"; 
  fichiers[8] = "images/diablo9.png"; 
  fichiers[9] = "images/diablo10.png"; 
  fichiers[10] = "images/diablo11.png"; 
  fichiers[11] = "images/diablo12.png"; 
  fichiers[12] = "images/diablo13.png"; 
  fichiers[13] = "images/diablo14.png"; 
  fichiers[14] = "images/diablo15.png"; 
  fichiers[15] = "images/diablo16.png"; 

  test = new animPict(16, fichiers, 100);
  
  SDL_Color fg, bg;
  fg.r = 255; fg.g = 255; fg.b = 0;
  bg.r = 0; bg.g = 0; bg.b = 0;

  SDL_Surface *Txt[3];
  Txt[0] = Texte("Hello", "babelfish.ttf", 40, fg, bg); 
  Txt[1] = Texte("World", "babelfish.ttf", 40, fg, bg); 
  Txt[2] = Texte("!!!!!", "babelfish.ttf", 40, fg, bg); 

  test2 = new animPict(3, Txt, 500);
  test2->SetColorKey(SDL_SRCCOLORKEY, 0);
  test2->SetAlpha(SDL_SRCALPHA, 127);

}

int main(int argc, char *argv[], char *env[])
{
  InitSDL();
  loadAnims();

  while(!Quitter)
  {
    affichage();
    process_events();
  }

  SDL_FreeSurface(Screen);
  return 0;
}
