#ifndef _ANIMATED_PICTURES
#define _ANIMATED_PICTURES

class animPict
{
public:
  animPict(int num, char **fichiers, int delay);
  animPict(int num, SDL_Surface **images, int delay);
  ~animPict();
  void SetColorKey(Uint32 flags, Uint32 key);
  void SetAlpha(Uint32 flags, Uint32 alpha);
  SDL_Surface *getPicture() { animer(); return Pictures[animPos % nbPict]; };
  void animer();
private:
  SDL_Surface **Pictures;
  int nbPict;
  int animPos;
  int delay;
  Uint32 nextTime;
};

#endif
