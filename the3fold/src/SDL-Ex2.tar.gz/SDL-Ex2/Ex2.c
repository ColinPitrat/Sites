// -=(the3fold)=-
//
// Ex2.c
// Exemple n�2 d'utilisation de SDL
// Affiche un rectangle vert � l'�cran
//

#include <SDL/SDL.h>
#include <stdio.h>
#include <stdlib.h>

unsigned char Quitter = 0;
SDL_Rect rect;
SDL_Surface *Screen, *rectangle;

void affichage()
{
  // Coloration des surfaces
  SDL_FillRect(rectangle, NULL, SDL_MapRGB(rectangle->format, 0, 255, 0));
  SDL_FillRect(Screen, NULL, 0);
  
  // D�finition de la zone � l'�cran
  rect.x = (Screen->w / 2) - (rect.w / 2);
  rect.y = (Screen->h / 2) - (rect.h / 2);
  rect.w = Screen->w / 2;
  rect.h = Screen->h / 2;
  
  // Blit de la surface � l'�cran et affichage
  SDL_BlitSurface(rectangle, NULL, Screen, &rect);
  SDL_Flip(Screen);
}

// Fonction se chargeant de tous les evenements
static void process_events(void)
{
   SDL_Event event;
   while(SDL_PollEvent(&event))
   {
      switch(event.type)
      {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_ESCAPE:      
          Quitter = 1;
          break;
        default:
          break;
        }
        break;
      case SDL_QUIT:
	 Quitter = 1;
	 break;
      }
   }
}

void InitSDL()
{
  // Initialisation de SDL
  if (SDL_Init (SDL_INIT_VIDEO) < 0) 
  {
    fprintf (stderr, "Erreur d'initialisation de SDL: %s\n", SDL_GetError ());
    exit(-1);
  }
  atexit (SDL_Quit); 
  
  // Initialisation de SDL_Video
  Screen = SDL_SetVideoMode (640, 480, 16, SDL_SWSURFACE | SDL_DOUBLEBUF);
  if (Screen == NULL) 
  {
    fprintf (stderr, "Erreur d'initialisation du mode video: %s\n", SDL_GetError ());
    exit(-1);
  }
  
  // Allocation de la surface (pour l'instant vide)
  rectangle = SDL_CreateRGBSurface(SDL_SWSURFACE, 320, 240, 32, 0, 0, 0, 0);
  
  // Titre de fen�tre
  SDL_WM_SetCaption ("-=(the3fold)=- Exemple 2", NULL);
}

int main (int argc, char **argv)
{
  InitSDL();

  while (!Quitter) 
  {
    process_events();
    affichage(); 
  }
  
  // Lib�ration de la surface rectangle
  SDL_FreeSurface(rectangle);
  return 0;
}
