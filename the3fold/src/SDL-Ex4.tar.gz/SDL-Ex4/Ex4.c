// -=(the3fold)=-
//
// Ex4.c
// Exemple n�4 d'utilisation de SDL
// Charge et affiche une image de format quelconque
//
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <stdio.h>

unsigned char Quitter = 0;
SDL_Surface *screen;

SDL_Surface *loadImage(char *fileName)
{
   SDL_Surface *image;

   image = IMG_Load(fileName);
   if(image == NULL)
   {
      fprintf(stderr, "Impossible de charger %s : %s\n", fileName, SDL_GetError());
      return NULL;
   }

   return image;
}

static void process_events(void)
{
   SDL_Event event;
   while(SDL_PollEvent(&event))
   {
      switch(event.type)
      {
      case SDL_KEYDOWN:
        switch(event.key.keysym.sym)
        {
        case SDLK_ESCAPE:      
          Quitter = 1;
          break;
        default:
          break;
        }
        break;
      case SDL_QUIT:
	 Quitter = 1;
	 break;
      }
   }
}

void InitSDL()
{
  if(SDL_Init(SDL_INIT_VIDEO) < 0)
  {
    fprintf(stderr,"Impossible d'initialiser SDL : %s.\n", SDL_GetError());
    exit(-1);
  }
  atexit(SDL_Quit);

  screen = SDL_SetVideoMode(640, 480, 24, SDL_SWSURFACE | SDL_ANYFORMAT);

  if(screen == NULL)
  {
    fprintf(stderr,"Impossible de s�lectionner le mode video : %s.\n", SDL_GetError());
    return -1;
  }

  SDL_WM_SetCaption("-=(the3fold)=- Exemple n�4", NULL);
}

int main(int argc, char *argv[], char *env[])
{
  if(argc==2)
  {
    InitSDL();
    SDL_Surface *image;   
    image = loadImage(argv[1]);

    if(SDL_BlitSurface(image, NULL, screen, NULL) < 0)
      fprintf(stderr, "Erreur de BlitSurface : %s\n", SDL_GetError());

    while(!Quitter)
    {
      SDL_UpdateRect(screen, 0, 0, image->w, image->h);
      process_events();
    }

    SDL_FreeSurface(image);

    return 0;
  }
  else
  {
    fprintf(stderr,"Syntaxe : %s <imagename>\n", argv[0]);
    return 0;
  }
}
